<?php 
include('db/db.php');
$ID_get = $_GET['s'];


 $q = "SELECT * FROM shehia WHERE wilaya ='$ID_get'";
 $res = mysqli_query($conn, $q) or die("Error : ".mysqli_error($conn));
 $num = 0;
 echo '<option value="">Chagua shehia</option>';
  while($row = mysqli_fetch_array($res)) {
              echo '<option value="'.$row[1].'">'.$row[1].'</option>';
            
  }
?> 