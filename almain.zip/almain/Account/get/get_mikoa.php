<?php 
include('db/db.php');
$ID_get = $_GET['r'];


 $query = "SELECT * FROM wilaya WHERE mkoaName ='$ID_get'";
 $result = mysqli_query($conn, $query) or die("Error : ".mysqli_error($conn));
 $num = 0;
 echo '<option value="">Chagua Wilaya</option>';
  while($row = mysqli_fetch_array($result)) {
              echo '<option value="'.$row[1].'">'.$row[1].'</option>';
            
  }
?> 

