<?php 
include('db/db.php');
$ID = $_GET['q'];


 $query = "SELECT * FROM  madarasa WHERE level_class ='$ID'";
 $result = mysqli_query($conn, $query) or die("Error : ".mysqli_error($conn));
 $num = 0;
 echo '<option value="">Chagua Darasa</option>';
  while($row = mysqli_fetch_array($result)) {
              echo '<option value="'.$row[1].'">'.$row[1].'</option>';
            
  }
?> 

