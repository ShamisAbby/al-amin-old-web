<?php

$host= "localhost";
$user= "root";
$password = "";

$db = "alamin";

$conn = mysqli_connect($host, $user, $password, $db);

if (!$conn) {
	echo "Connection failed!";
}