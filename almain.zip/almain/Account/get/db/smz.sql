-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2022 at 01:00 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smz`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendence_primary`
--

CREATE TABLE `attendence_primary` (
  `id` int(11) NOT NULL,
  `reg` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `class` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL,
  `year` year(4) NOT NULL DEFAULT current_timestamp(),
  `school` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendence_primary`
--

INSERT INTO `attendence_primary` (`id`, `reg`, `name`, `gender`, `class`, `date`, `time`, `status`, `year`, `school`) VALUES
(357, '22/F1A/001', 'Ali Juma Salim', 'M', 'Form One A', '2022-03-07', '12:52:13', 'ABSENT', 2022, 'Secondary'),
(358, '22/F1A/002', 'Sania Salim Juma', 'F', 'Form One A', '2022-03-07', '12:52:13', 'PRESENT', 2022, 'Secondary'),
(359, '22/F1A/003', 'Huzaima Juma Salim', 'F', 'Form One A', '2022-03-07', '12:52:13', 'PRESENT', 2022, 'Secondary'),
(362, '002', 'Yahya Mwinyi Ally', 'F', 'STD 6 A & B', '2022-03-07', '13:12:14', 'PRESENT', 2022, 'Primary'),
(363, '22/STD6/001', 'Ramla Salim Juma', 'F', 'STD 6 A & B', '2022-03-07', '13:12:14', 'PRESENT', 2022, 'Primary'),
(364, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', '2022-03-07', '13:12:14', 'PRESENT', 2022, 'Primary'),
(365, '002', 'Yahya Mwinyi Ally', 'M', 'STD 6 A & B', '2022-03-07', '13:16:46', 'PRESENT', 2022, 'Primary'),
(366, '22/STD6/001', 'Ramla Salim Juma', 'F', 'STD 6 A & B', '2022-03-07', '13:16:46', 'ABSENT', 2022, 'Primary'),
(367, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', '2022-03-07', '13:16:47', 'PRESENT', 2022, 'Primary'),
(368, '22/STD6/003', 'NAIMA JUMA ALI', 'F', 'STD 6 A & B', '2022-03-07', '13:16:47', 'ABSENT', 2022, 'Primary'),
(369, '002', 'Yahya Mwinyi Ally', 'M', 'STD 6 A & B', '2022-03-07', '13:17:50', 'PRESENT', 2022, 'Primary'),
(370, '22/STD6/001', 'Ramla Salim Juma', 'F', 'STD 6 A & B', '2022-03-07', '13:17:51', 'ABSENT', 2022, 'Primary'),
(371, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', '2022-03-07', '13:17:51', 'PRESENT', 2022, 'Primary'),
(372, '22/STD6/003', 'NAIMA JUMA ALI', 'F', 'STD 6 A & B', '2022-03-07', '13:17:51', 'ABSENT', 2022, 'Primary'),
(373, '001', 'Ali Salim Juma', 'M', 'KG 1', '2022-03-07', '13:33:44', 'PRESENT', 2022, 'Primary'),
(374, 'STD 6/01', 'Ali Salim Ali', 'M', 'STD 6 C & D', '2019-03-01', '13:33:57', 'PRESENT', 2019, 'Primary'),
(375, '001', 'Ali Salim Juma', 'M', 'KG 1', '2022-03-07', '14:59:55', 'PRESENT', 2022, 'Primary'),
(376, '22/KG1/001', 'AMINA ALI MUSSA', 'F', 'KG 1', '2022-03-07', '14:59:55', 'ABSENT', 2022, 'Primary'),
(377, '22/KG1/002', 'AMINA ALI SALIM', 'F', 'KG 1', '2022-03-07', '14:59:55', 'ABSENT', 2022, 'Primary'),
(378, '22/KG1/003', 'ASHA JUMA SALIM', 'F', 'KG 1', '2022-03-07', '14:59:55', 'PRESENT', 2022, 'Primary'),
(379, '22/KG1/004', 'ASHA SALIM ALI', 'F', 'KG 1', '2022-03-07', '14:59:55', 'PRESENT', 2022, 'Primary'),
(380, '22/KG1/005', 'NAIMA KOMBO ABUU', 'F', 'KG 1', '2022-03-07', '14:59:55', 'ABSENT', 2022, 'Primary'),
(381, '002', 'Yahya Mwinyi Ally', 'M', 'STD 6 A & B', '2022-03-07', '17:00:22', 'ABSENT', 2022, 'Primary'),
(382, '22/STD6/001', 'Ramla Salim Juma', 'F', 'STD 6 A & B', '2022-03-07', '17:00:22', 'PRESENT', 2022, 'Primary'),
(383, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', '2022-03-07', '17:00:22', 'ABSENT', 2022, 'Primary'),
(384, '22/STD6/003', 'NAIMA JUMA ALI', 'F', 'STD 6 A & B', '2022-03-07', '17:00:22', 'ABSENT', 2022, 'Primary'),
(385, '002', 'Yahya Mwinyi Ally', 'M', 'STD 6 A & B', '2022-03-07', '17:08:13', 'ABSENT', 2022, 'Primary'),
(386, '22/STD6/001', 'Ramla Salim Juma', 'F', 'STD 6 A & B', '2022-03-07', '17:08:13', 'ABSENT', 2022, 'Primary'),
(387, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', '2022-03-07', '17:08:13', 'ABSENT', 2022, 'Primary'),
(388, '22/STD6/003', 'NAIMA JUMA ALI', 'F', 'STD 6 A & B', '2022-03-07', '17:08:13', 'PRESENT', 2022, 'Primary'),
(389, '22/F1A/001', 'Ali Juma Salim', 'M', 'Form One A', '2022-03-07', '17:09:08', 'PRESENT', 2022, 'Secondary'),
(390, '22/F1A/002', 'Sania Salim Juma', 'F', 'Form One A', '2022-03-07', '17:09:08', 'ABSENT', 2022, 'Secondary'),
(391, '22/F1A/003', 'Huzaima Juma Salim', 'F', 'Form One A', '2022-03-07', '17:09:09', 'ABSENT', 2022, 'Secondary'),
(392, 'S22/MS/002', 'Yahya Mwinyi Ally', 'M', 'Form One A', '2022-03-07', '17:09:09', 'PRESENT', 2022, 'Secondary'),
(393, '005', 'Juma Hamad Ali', 'M', 'Form Four B', '2022-03-07', '17:10:44', 'ABSENT', 2022, 'Secondary'),
(394, '00045', 'Hamina', 'F', 'STD 1 A & B', '2022-03-07', '17:12:20', 'ABSENT', 2022, 'Primary'),
(395, '002', 'Yahya Mwinyi Ally', 'M', 'STD 6 A & B', '2022-03-07', '17:15:49', 'ABSENT', 2022, 'Primary'),
(396, '22/STD6/001', 'Ramla Salim Juma', 'F', 'STD 6 A & B', '2022-03-07', '17:15:49', 'PRESENT', 2022, 'Primary'),
(397, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', '2022-03-07', '17:15:49', 'ABSENT', 2022, 'Primary'),
(398, '22/STD6/003', 'NAIMA JUMA ALI', 'F', 'STD 6 A & B', '2022-03-07', '17:15:49', 'ABSENT', 2022, 'Primary'),
(399, 'Ms/0002', 'Kombo', 'M', 'STD 5 C & D', '2022-03-07', '17:18:30', 'ABSENT', 2022, 'Primary'),
(400, 'MS/0006', 'Kichwa', 'M', 'STD 5 C & D', '2022-03-07', '17:18:30', 'ABSENT', 2022, 'Primary'),
(401, 'MS/001', 'JUMA ALI JUMA', '', '', '2022-03-09', '16:08:02', 'Aproved', 2022, ''),
(402, '002', 'Yahya Mwinyi Ally', 'M', 'STD 6 A & B', '2022-03-09', '16:30:04', 'PRESENT', 2022, 'Primary'),
(403, '22/STD6/001', 'Ramla Salim Juma', 'F', 'STD 6 A & B', '2022-03-09', '16:30:04', 'PRESENT', 2022, 'Primary'),
(404, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', '2022-03-09', '16:30:04', 'PRESENT', 2022, 'Primary'),
(405, '22/STD6/003', 'NAIMA JUMA ALI', 'F', 'STD 6 A & B', '2022-03-09', '16:30:04', 'PRESENT', 2022, 'Primary'),
(406, '002', 'Yahya Mwinyi Ally', 'M', 'STD 6 A & B', '2022-03-13', '12:26:39', 'PRESENT', 2022, 'Primary'),
(407, '22/STD6/001', 'Ramla Salim Juma', 'F', 'STD 6 A & B', '2022-03-13', '12:26:39', 'ABSENT', 2022, 'Primary'),
(408, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', '2022-03-13', '12:26:39', 'ABSENT', 2022, 'Primary'),
(409, '22/STD6/003', 'NAIMA JUMA ALI', 'F', 'STD 6 A & B', '2022-03-13', '12:26:40', 'ABSENT', 2022, 'Primary');

-- --------------------------------------------------------

--
-- Table structure for table `hostelfees`
--

CREATE TABLE `hostelfees` (
  `id` int(11) NOT NULL,
  `reg` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `hostel` varchar(50) NOT NULL,
  `pay` int(11) NOT NULL,
  `remain` int(11) NOT NULL DEFAULT 0,
  `fees` varchar(50) NOT NULL DEFAULT '200,000',
  `level` varchar(50) NOT NULL,
  `year` year(4) NOT NULL DEFAULT current_timestamp(),
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hostelfees`
--

INSERT INTO `hostelfees` (`id`, `reg`, `name`, `gender`, `hostel`, `pay`, `remain`, `fees`, `level`, `year`, `date`) VALUES
(2, 'HC/001', 'KASSIM SULEIMAN SALIM', 'M', 'C', 200000, 0, '200,000', 'Secondary', 2022, '2022-03-09'),
(3, 'HB/002', 'Juma Hamad Juma', 'M', 'A', 60000, 0, '200,000', 'Primary', 2022, '2022-03-09'),
(5, 'HB', 'ALI JUMA', 'Male', 'B', 100000, 0, '200,000', 'Secondary', 2022, '2022-03-09'),
(6, 'tt', 'uuu', 'Male', 'B', 66666, 0, '200,000', 'Primary', 2022, '2022-03-14');

-- --------------------------------------------------------

--
-- Table structure for table `p_add_student`
--

CREATE TABLE `p_add_student` (
  `id` int(11) NOT NULL,
  `reg` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `class` varchar(200) NOT NULL,
  `school` varchar(40) NOT NULL,
  `year` year(4) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `p_add_student`
--

INSERT INTO `p_add_student` (`id`, `reg`, `name`, `gender`, `class`, `school`, `year`) VALUES
(40, '00045', 'Hamina', 'F', 'STD 1 A & B', 'Primary', 2022),
(13, '001', 'Ali Salim Juma', 'M', 'KG 1', 'Primary', 2022),
(24, '002', 'Yahya Mwinyi Ally', 'M', 'KG 2', 'Primary', 2022),
(39, '009', 'Hamad Ali', 'F', 'Form Four B', 'Secondary', 2022),
(12, '21/STD 5/001', 'AMINA SALIMU JUMA', 'F', 'STD 5 A & B', 'Primary', 2022),
(29, '22/F1A/001', 'Ali Juma Salim', 'M', 'Form One A', 'Secondary', 2022),
(30, '22/F1A/002', 'Sania Salim Juma', 'F', 'Form One A', 'Secondary', 2022),
(33, '22/KG1/001', 'AMINA ALI MUSSA', 'F', 'KG 1', 'Primary', 2022),
(34, '22/KG1/002', 'AMINA ALI SALIM', 'F', 'KG 1', 'Primary', 2022),
(35, '22/KG1/003', 'ASHA JUMA SALIM', 'F', 'KG 1', 'Primary', 2022),
(36, '22/KG1/004', 'ASHA SALIM ALI', 'F', 'KG 1', 'Primary', 2022),
(37, '22/KG1/005', 'NAIMA KOMBO ABUU', 'F', 'KG 1', 'Primary', 2022),
(9, '22/STD6/002', 'SALMA SALIM KOMBO', 'F', 'STD 6 A & B', 'Primary', 2022),
(32, '22/STD6/003', 'NAIMA JUMA ALI', 'F', 'STD 6 A & B', 'Primary', 2022),
(41, 'Ms/0002', 'Kombo', 'M', 'STD 5 C & D', 'Primary', 2022),
(42, 'MS/0006', 'Kichwa', 'M', 'STD 5 C & D', 'Primary', 2022),
(26, 'S22/MS/002', 'Yahya Mwinyi Ally', 'M', 'Form One A', 'Secondary', 2022),
(25, 'STD 6/01', 'Ali Salim Ali', 'M', 'STD 6 C & D', 'Primary', 2022);

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` int(11) NOT NULL,
  `reg` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `level` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL DEFAULT 0,
  `date` date NOT NULL,
  `bank` varchar(50) NOT NULL,
  `accountno` varchar(20) NOT NULL,
  `signatur` varchar(50) NOT NULL,
  `year` year(4) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `reg`, `name`, `gender`, `level`, `amount`, `date`, `bank`, `accountno`, `signatur`, `year`) VALUES
(7, 'TP/001/2001', 'ALI SALIM JUMA', 'Male', 'Diploma', 350000, '2022-03-09', 'PBZ', '0788884568', 'Aproved', 2022),
(8, 'TP/001/2002', 'Salim Juma Ali', 'Male', 'Diploma', 350000, '2022-03-09', 'PBZ ISLAMIC', '0727290875', 'Not Aproved', 2022),
(9, 'TP/001/2003', 'Amina Juma Ali', 'Female', 'Diploma', 350000, '2022-03-09', 'NMB', '97865432223', 'Aproved', 2022),
(10, 'ML/001/2001', 'JUMA ABUU KOMBO', 'Male', 'Form 4', 250000, '2022-03-09', 'PBZ ISLAMIC', '07886543322', 'Aproved', 2022),
(11, 'TP/001/2001', 'ALI SALIM JUMA', 'Male', 'Diploma', 350000, '2022-03-09', 'PBZ', '0788884568', 'Aproved', 2022),
(12, 'TP/001/2002', 'Salim Juma Ali', 'Male', 'Diploma', 350000, '2022-03-09', 'PBZ ISLAMIC', '0727290875', 'Aproved', 2022),
(13, 'TP/001/2003', 'Amina Juma Ali', 'Female', 'Diploma', 350000, '2022-03-09', 'NMB', '97865432223', 'Aproved', 2022),
(14, 'TP/001/2001', 'ALI SALIM JUMA', 'Male', 'Diploma', 350000, '2022-03-09', 'PBZ', '0788884568', 'Not Aproved', 2022),
(15, 'TP/001/2002', 'Salim Juma Ali', 'Male', 'Diploma', 350000, '2022-03-09', 'PBZ ISLAMIC', '0727290875', 'Not Aproved', 2022),
(16, 'TP/001/2003', 'Amina Juma Ali', 'Female', 'Diploma', 350000, '2022-03-09', 'NMB', '97865432223', 'Not Aproved', 2022),
(17, '002', 'Ali Salim Ali', 'Male', 'Prof', 3000000, '2022-03-14', 'PBZ ISLAMIC', '12345687766', 'Aproved', 2022),
(18, 'TP/001/2003', 'Amina Juma Ali', 'Male', 'Prof', 9350000, '2022-03-14', 'NMB', '97865432223', 'Aproved', 2022),
(19, '001', 'Ali Salim ', 'Male', 'Degree', 500000, '2022-03-14', 'PBZ', '23333333333', 'Aproved', 2022),
(20, '002', 'Ali Salim Ali', 'Male', 'Prof', 3000000, '2022-03-14', 'PBZ ISLAMIC', '12345687766', 'Aproved', 2022),
(21, 'TP/001/2003', 'Amina Juma Ali', 'Male', 'Prof', 9350000, '2022-03-14', 'NMB', '97865432223', 'Aproved', 2022);

-- --------------------------------------------------------

--
-- Table structure for table `studentfees`
--

CREATE TABLE `studentfees` (
  `id` int(11) NOT NULL,
  `reg` varchar(50) NOT NULL,
  `name` varchar(70) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL,
  `pay_amount` int(11) NOT NULL DEFAULT 0,
  `pay_date` date NOT NULL,
  `remain_amount` int(11) NOT NULL DEFAULT 0,
  `total_fees` int(11) NOT NULL DEFAULT 800000,
  `reg_date` date NOT NULL DEFAULT current_timestamp(),
  `par_yaer` year(4) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentfees`
--

INSERT INTO `studentfees` (`id`, `reg`, `name`, `gender`, `level`, `pay_amount`, `pay_date`, `remain_amount`, `total_fees`, `reg_date`, `par_yaer`) VALUES
(3, '001', 'Yahya Mwinyi ', 'M', 'Secondary', 450000, '2022-02-14', 0, 800000, '2022-03-09', 2022),
(6, 'PS2415/001', 'SANIA JUMA ALI', 'F', 'Primary', 900000, '2022-03-10', 0, 800000, '2022-03-09', 2022),
(7, 'NS2415/002', 'Juma Hamad Ali', 'Male', 'Nussary', 250000, '2022-03-31', 0, 800000, '2022-03-09', 2022),
(8, 'P/001', 'Ali Kombo Juma', 'Male', 'Primary', 350000, '2022-03-14', 0, 800000, '2022-03-14', 2022),
(9, 'P/003', 'Hamis Ali Juma', 'Male', 'Secondary', 450000, '2022-03-14', 0, 800000, '2022-03-14', 2022),
(10, 'P/006', 'Amina Juma Mzee', 'Male', 'Secondary', 2900000, '2022-03-14', 0, 800000, '2022-03-14', 2022);

-- --------------------------------------------------------

--
-- Table structure for table `studentinf`
--

CREATE TABLE `studentinf` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `year` year(4) NOT NULL,
  `mzazi` varchar(250) NOT NULL,
  `MzaziSim` varchar(15) NOT NULL,
  `School` varchar(20) NOT NULL,
  `Reg` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentinf`
--

INSERT INTO `studentinf` (`id`, `name`, `gender`, `dob`, `address`, `year`, `mzazi`, `MzaziSim`, `School`, `Reg`) VALUES
(29, 'Yahya Mwinyi Ally', 'Male', '1995-05-10', 'Msuka Chanjaani', 2020, 'Mwinyi Ali Mwinyi', '0778141964', 'Primary', 'MS/P/001/2022'),
(41, 'Yahya Mwinyi Ally', 'Male', '1996-05-10', 'Msuka Chanjaani', 2016, 'Mwinyi Ali Mwinyi', '0773596632', 'Secondary', '16/SEC/0045'),
(46, 'ALI JUMA ALI', 'Male', '2021-06-07', 'MSUKA', 2022, 'ALI JUMA', '0887665645', 'Secondary', '21/SEC/001'),
(49, 'SAMIA SALIM ALI', 'Male', '2022-02-08', 'KONDE', 2020, 'YAHYA ALI', '0978677564', 'Primary', '22/P/MS/014'),
(51, 'YAHYA MWINYI ALLY', 'Male', '2022-02-12', 'MSUKA TAPONI', 2004, 'FATMA SALIM JUMA', '0678954321', 'Primary', '22/P/Ms/055'),
(52, 'Yahya Mwinyi Ally', 'Male', '2022-03-09', 'Msuka', 2016, 'Mwinyi Ali Mwinyi', '0773596632', 'Secondary', '16/SEC/001'),
(56, 'SALIMU ALI SALIM', 'Male', '2026-02-22', 'Konde', 2016, 'Samir Juma Ali', '0786543234', 'Secondary', '16/SEC/002'),
(59, 'Yahya', 'Male', '2021-10-15', 'Msuka', 2000, 'Yahya Mwinyi', '0771415675', 'Secondary', '001'),
(60, 'Amina Juma Ali', 'Male', '2022-02-19', 'Msuka Taponi', 2000, 'Ali ', '0877777776', 'Primary', 'P/005/2017'),
(61, 'AMINA SALIM ALI', 'Male', '1999-05-04', 'KICHAKA PUMU', 2000, 'SALIM ALI JUMA', '0778324567', 'Secondary', '200/SCE/001'),
(63, 'AMINA JUMA SALIM', 'Male', '1994-12-14', 'TAPONI', 2000, 'SULEIMAN JUMA SALIM', '0778123456', 'Secondary', '200/SCE/002'),
(64, 'ASHA KOMBO FAKI', 'Male', '1995-10-31', 'SEBLENI', 2000, 'ZUWENA SHAMEE JUMA', '0786543288', 'Secondary', '200/SCE/003'),
(67, 'Sania Juma Ali', 'Male', '1979-10-27', 'Konde ', 2022, 'Mjuani Ali Kombo', '0786155262', 'Primary', 'P/001/2022'),
(71, 'Juam Kombo Ali', 'Male', '2013-07-26', 'Konde', 2022, 'Ali Salim Juma', '0678352637', 'Primary', 'P/MS/018'),
(73, 'AMINA HAMZA JUMA', 'Male', '1999-12-06', 'UNGI', 2017, 'NUWAIRA JUMA KOMBO', '0786543256', 'Primary', 'P/Ms/0030'),
(74, 'Amina Salim Siyahy', 'Male', '1993-07-14', 'Pingwe', 2017, 'Shadia Salim ', '0786543256', 'Primary', 'P/Ms/0031'),
(75, 'ALI JUMA HAMAD', 'Male', '2022-03-13', 'UNGI', 2022, 'YAHYA', '077814357', 'Secondary', '22/SEC/0015'),
(77, 'NUWAIRA JUMA ALI', 'Male', '1998-07-31', 'GOMBANI', 2006, 'HASHIM JUMA ALI', '0778432455', 'Primary', '22/P/0037'),
(78, 'SULEIMAN JUMA ALI', 'Male', '1995-02-23', 'KICHAKA PUMU', 2003, 'BIKAME', '0765432345', 'Primary', '22/P/0045'),
(79, 'Amina Juma Ali', 'Female', '2000-12-08', 'Kisauni', 2022, 'Amian Ali Juam', '0778543234', 'Secondary', '22/S/001'),
(80, '', '', '0000-00-00', '', 0000, '', '', 'Primary', '');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(11) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `class` varchar(250) NOT NULL,
  `room` varchar(250) NOT NULL,
  `time` time NOT NULL,
  `teacher` varchar(250) NOT NULL,
  `school` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `year` year(4) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `subject`, `class`, `room`, `time`, `teacher`, `school`, `date`, `year`) VALUES
(2, 'English', 'Form One A', 'Room 2', '04:30:00', 'Kombo Kichwa', 'Secondary', '2022-03-14', 2022),
(6, 'Michezo', 'STD 2 A & B', 'ROOM 7', '10:54:00', 'Ms. Amina Ali', 'Primary', '2022-03-15', 2022),
(7, 'ICT', 'Form One A', 'ROOM 10', '10:56:00', 'Mr. Yahya Mwinyi', 'Secondary', '2022-03-22', 2022),
(8, 'Arabic', 'Form One A', 'ROOM 2', '14:55:00', 'Mr. Kassim Salim', 'Secondary', '2022-03-15', 2022),
(9, 'Arabic', 'STD 6 A & B', 'ROOM 1', '22:56:00', 'Mr. Yahya Mwinyi', 'Primary', '2022-03-23', 2022),
(10, 'Chemistry', 'Form One C', 'ROOM 3', '00:56:00', 'Mr. Juma Ali', 'Secondary', '2022-03-31', 2022),
(11, 'Uraia', 'KG 2', 'ROOM 1', '10:57:00', 'Mr. Yahya Mwinyi', 'Primary', '2022-03-29', 2022);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `jina` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `sim` varchar(10) NOT NULL,
  `date_reg` date NOT NULL DEFAULT current_timestamp(),
  `password` varchar(50) NOT NULL,
  `status` enum('Teacher','Account','Adminstrator') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `jina`, `email`, `gender`, `sim`, `date_reg`, `password`, `status`) VALUES
(12, 'Ali Juma Ali', 'alijuma@gmail.com', 'M', '786564342', '2022-03-02', '1234', 'Account'),
(32, 'Ali Salim Juma', 'alisalimu@gmail.com', 'M', '0678095564', '2022-03-14', '1234', 'Teacher'),
(33, 'Yahya Mwinyi ', 'yahya@gmail.com', 'M', '0778141964', '2022-03-14', '123', 'Adminstrator');

-- --------------------------------------------------------

--
-- Table structure for table `wafanyakazi`
--

CREATE TABLE `wafanyakazi` (
  `reg` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `level` varchar(50) NOT NULL,
  `timework` int(11) NOT NULL,
  `year` year(4) NOT NULL DEFAULT current_timestamp(),
  `amount` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `type` varchar(60) NOT NULL,
  `bank` varchar(50) NOT NULL,
  `accountno` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wafanyakazi`
--

INSERT INTO `wafanyakazi` (`reg`, `name`, `gender`, `level`, `timework`, `year`, `amount`, `id`, `type`, `bank`, `accountno`) VALUES
('001', 'Ali Salim ', 'Male', 'Degree', 2, 2022, 500000, 34, 'Mafanyakazi', 'PBZ', '23333333333'),
('002', 'Ali Salim Ali', 'Male', 'Prof', 5, 2022, 3000000, 33, 'Mafanyakazi', 'PBZ ISLAMIC', '12345687766'),
('0054', 'Juama Ali JUma', 'Male', '--Select_Level--', 6, 2022, 250000, 32, 'Mafanyakazi', 'PBZ', '76624365654'),
('TP/001/2003', 'Amina Juma Ali', 'Male', 'Prof', 1, 2022, 9350000, 25, 'Mafanyakazi', 'NMB', '97865432223');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendence_primary`
--
ALTER TABLE `attendence_primary`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `hostelfees`
--
ALTER TABLE `hostelfees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `p_add_student`
--
ALTER TABLE `p_add_student`
  ADD PRIMARY KEY (`reg`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studentfees`
--
ALTER TABLE `studentfees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studentinf`
--
ALTER TABLE `studentinf`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Reg` (`Reg`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `sim` (`sim`);

--
-- Indexes for table `wafanyakazi`
--
ALTER TABLE `wafanyakazi`
  ADD PRIMARY KEY (`reg`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendence_primary`
--
ALTER TABLE `attendence_primary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=410;

--
-- AUTO_INCREMENT for table `hostelfees`
--
ALTER TABLE `hostelfees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `p_add_student`
--
ALTER TABLE `p_add_student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `studentfees`
--
ALTER TABLE `studentfees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `studentinf`
--
ALTER TABLE `studentinf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `wafanyakazi`
--
ALTER TABLE `wafanyakazi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
