
<?php
include("db/db.php");
$id=$_GET['id'];
$con=mysqli_query($conn,"DELETE FROM wajane WHERE id=$id ");
if($con){
	header("location:../wajane_table.php");	
}
else{
	echo "failed";
}

?>