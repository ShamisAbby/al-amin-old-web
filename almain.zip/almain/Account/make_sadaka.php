<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


<?php
include("../db/db.php");
?>


<?php include('header.php') ?>



  <body class="app sidebar-mini">
    <!-- Navbar-->
    

<?php include('topmenu.php') ?>



    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
   

   <?php include('navbar.php') ?>




    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>Views Member</h1>
          <p>Watu walio Sajiliwa katika mfumo</p>
        </div>

        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Tables</li>
          <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
        </ul>
      </div>

      <div class="col-lg-12">
         <form action="make_sadaka.php" method="POST">
        <div class="form-row">
              
               <div class="col-md-4 mb-3">
                  <label>Registration number</label>
                  <select class="form-control" name="type" required="">
                        <option value="">--Select_Year--</option> 
                        <option value="widows">widows</option>
                        </select>
               </div>


               <div class="col-md-4 mb-3">
                  <label>Registration number</label>
                  <select class="form-control" name="Gender" required="">
                        <option value="">--Select_Year--</option> 
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                  </select>
               </div>



               <div class="col-md-2 mb-4">
                <label>Searching</label>
                  <br>
                  <input type="submit" class="btn btn-primary" value="Searching" name="submit"> 
                  
                </div>

      </div>
      </form>
    </div>

           
 


      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <div class="table-responsive">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th style="font-size: 15px">S/n</th>
                      <th style="font-size: 15px">Reg No</th>
                      <th style="font-size: 15px">Name</th>
                      <th style="font-size: 15px">D.of. B</th>
                      <th style="font-size: 15px">Gender</th>
                      <th style="font-size: 15px">Address</th>
                      <th style="font-size: 15px">Phone</th>
                      <th style="font-size: 15px">Type</th>
                      <th style="font-size: 15px">Sponser</th>
                      <th style="font-size: 15px">Charity</th>
                     </tr>
                  </thead>
                  <tbody>


    <?php

      if(isset($_POST['submit'])){
          $type = $_POST['type'];
          $Gender = $_POST['Gender'];
              

            $data = mysqli_query($conn, "SELECT * FROM wanafunzi WHERE type='$type' AND Gender='$Gender'");
            $kuesabu=0;
            $kuesabu ++; 

            $rows= mysqli_num_rows($data);

            if(mysqli_num_rows($data) > 0){
              while($row=mysqli_fetch_array($data))
            {
             ?>

                   <tr>
                    <td>
                          <?php echo $kuesabu  ?>
                      </td>


                       <td>
                          <?php echo $row['regNo'];  ?>
                      </td>


                      <td>
                          <?php echo $row['name'];  ?>
                      </td>

                      <td>
                          <?php echo $row['dob'];  ?>
                      </td>

                      <td>
                          <?php echo $row['gender'];  ?>
                      </td>

                      
                      <td>
                          <?php echo $row['shehia'];  ?>
                      </td>

                      <td>
                          <?php echo $row['sim'];  ?>
                      </td>

                      
                      <td>
                          <?php echo $row['type'];  ?>
                      </td>



                    <td>
                      <a href="make_sponser.php?id=<?php echo $row["id"]; ?>" title="edit" class="delete" onclick="return confirm('Do you  want to Add Sponser?') "><b style="color: blue; font-size: 15px"><i class='fa fa-plus-circle' style="font-size: 20px"></i></a>

                    </td> 

                    <td>
                      <a href="add_sadaka.php?id=<?php echo $row["id"]; ?>" title="edit" class="delete" onclick="return confirm('Do you  want to select Charity?') "><b style="color: blue; font-size: 15px"><i class='fa fa-plus-circle' style="font-size: 20px"></i></a>

                    </td> 
                     

                                    

                      
                    </tr>

                     <?php

        $kuesabu ++;
      }
}

else{
    echo"<div class= 'alert alert-success'><center><strong><b>No Record</strong></b></div>";
  }


}
?>
                                                        
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    

    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>


     
  </body>
</html>