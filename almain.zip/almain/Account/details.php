<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


<?php      
require("single/pdf/fpdf.php");
     $pdf = new FPDF();
    include('../db/db.php');

 ?>
 


<?php
$pdf->SetTitle("Al-Amin Relief Foundation");
 if(isset($_POST["generate_pdf"]))  
 {  
   $id=$_GET['id'];
     $sql = mysqli_query($conn, "SELECT * FROM wanafunzi WHERE id =$id");
          
        $row=mysqli_fetch_assoc($sql);


     $pdf->AddPage();
              $pdf->SetFont("Times","",11);

             $pdf->Cell(50,10,"Al-Amin Relief Foundation",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(20,10,"P.O.BOx:",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(77,10,"Tel: +255 778 753  384 / +255 776 529 210",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(65,10,"E-Mail:info@alaminfoundation.or.tz",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(54,10,"Website:laminfoundation.or.tz",60,0,"C");
             $pdf->Ln(7);
             $pdf->Line(12,45,200,45);

             $pdf->Image("almin.jpeg",170,17,30);
             
                
                   
             $pdf->SetFont("Times","B",18);
                                   $pdf->SetTextColor(153,0,153);
             $pdf->Cell(185,10,"ORPHAN INFORMATION FORM",60,0,"C");

              
             $pdf->Ln(50); 
             $pdf->SetTextColor(32,32,32); 
                          
            
              $pdf->Image('images/'.$row['image'],167,65,30);
              $pdf->Ln(10);
              $pdf->SetFont("Times","B",14);
              $pdf->SetTextColor(0,0,255);
              $pdf->Cell(40,10,'Personal Information');
              $pdf->Ln(8);
              $pdf->SetTextColor(32,32,32);
              $pdf->SetFont("Times","B",12);
              $pdf->Cell(90,10,"Regstration Number :",1,0);
              $pdf->Cell(90,10,$row['regNo'],1,1);

              
              $pdf->SetTextColor(32,32,32);  
              $pdf->Cell(90,10,"Full Name :",1,0);
              $pdf->Cell(90,10,$row['name'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Gender:",1,0);
              $pdf->Cell(90,10,$row['gender'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Date of Birth:",1,0);
              $pdf->Cell(90,10,$row['dob'],1,1);


              $pdf->Ln(14);
              $pdf->SetTextColor(0,0,255);
              $pdf->Cell(40,10,'Residence Information');
              $pdf->Ln(8);
              $pdf->SetTextColor(32,32,32);  
              $pdf->Cell(90,10,"Religin :",1,0);
              $pdf->Cell(90,10,$row['mkoa'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Distrit:",1,0);
              $pdf->Cell(90,10,$row['wilaya'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Address",1,0);
              $pdf->Cell(90,10,$row['shehia'],1,1);



               $pdf->Ln(14);
              $pdf->SetTextColor(0,0,255);
              $pdf->Cell(40,10,'School Information');
              $pdf->Ln(8);
              $pdf->SetTextColor(32,32,32);  
              $pdf->Cell(90,10,"School Name :",1,0);
              $pdf->Cell(90,10,$row['school'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Level Study:",1,0);
              $pdf->Cell(90,10,$row['level'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Class Name",1,0);
              $pdf->Cell(90,10,$row['class'],1,1);


              $pdf->Ln(14);
              $pdf->SetTextColor(0,0,255);
              $pdf->Cell(40,10,'Disability Information');
              $pdf->Ln(8);
              $pdf->SetTextColor(32,32,32);  
              $pdf->Cell(90,10,"Illness:",1,0);
              $pdf->Cell(90,10,$row['maradhi'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Disability:",1,0);
              $pdf->Cell(90,10,$row['ulemavu'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Member",1,0);
              $pdf->Cell(90,10,$row['type'],1,1);


              $pdf->Ln(14);
              $pdf->SetTextColor(0,0,255);
              $pdf->Cell(40,10,'Guardian Information');
              $pdf->Ln(8);
              $pdf->SetTextColor(32,32,32);  
              $pdf->Cell(90,10,"Parent Death:",1,0);
              $pdf->Cell(90,10,$row['mzazi'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Guardian:",1,0);
              $pdf->Cell(90,10,$row['mlezi'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Phone Number",1,0);
              $pdf->Cell(90,10,$row['sim'],1,1);
              $pdf->Cell(90,10,"Sponser",1,0);
              $pdf->Cell(90,10,$row['status'],1,1);




              $pdf->Ln(20);
              $pdf->SetFont("Times","B",18);
              $pdf->SetTextColor(153,0,153);
 $pdf->Cell(185,10,"AL Amin Relief Foundation Zanzibar",60,0,"C");

$pdf->Ln(25);
$pdf->SetTextColor(153,0,0);
$pdf->SetFont("Times","B",12);
$pdf->Cell(50,5,'Birth Certificate of Child');
$pdf->Ln(8);
$pdf->Cell(50,5,'Medical Reports of Child');
$pdf->Ln(8);
$pdf->Cell(50,5,'UN Protection Letter');
$pdf->Ln(8);
$pdf->Cell(50,5,'Child School report');
$pdf->Ln(8);
$pdf->Cell(50,5,'Death Certificate of Father');



$pdf->Ln(10);
              $pdf->SetFont("Times","B",18);
              $pdf->SetTextColor(153,0,153);
 $pdf->Cell(185,10,"For office only",60,0,"C");
 $pdf->Ln(20);

 $pdf->Line(12,205,200,205);

 //$pdf->Cell("General Oficer",60,17,30);

              $pdf->Ln(8);
              $pdf->SetFont("Times","",14);
              $pdf->SetTextColor(0,0,255);  
              $pdf->Cell(90,10,"General Oficer",0,0);
              $pdf->Ln(10);
              $pdf->Cell(90,10,"...................................................",0,0);
              $pdf->Ln(10);
              $pdf->Cell(90,10,"Abdul-Rahma Ali Makame",0,0);


              $pdf->Ln(-15);
              $pdf->Cell(320,0,"Account Officer",60,50,"C");
              $pdf->Ln(10);
              $pdf->Cell(320,10,".........................................",60,0,"C");
              $pdf->Ln(10);
              $pdf->Cell(320,10,"Abdul-Rahma Ali Makame",60,0,"C");


              






             
            

 
 $pdf->output();
  }

 
?>


 ?>




 <?php
  include('../db/db.php');



$id=$_GET['id'];
$result=mysqli_query($conn,"SELECT * FROM wanafunzi WHERE id=$id");
while($res=mysqli_fetch_array($result)){
  $regNo=$res['regNo'];
  $name=$res['name'];
  $gender=$res['gender'];
  $dob=$res['dob'];
  $mkoa=$res['mkoa'];
  $wilaya=$res['wilaya'];
  $shehia=$res['shehia'];
  $school=$res['school'];
  $level=$res['level'];
  $class=$res['class'];
  $type=$res['type'];
  $maradhi=$res['maradhi'];
  $mlezi=$res['mlezi'];
  $ulemavu=$res['ulemavu'];
  $sim=$res['sim'];
  $image=$res['image'];
  $status=$res['status'];
    }
?>
 


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      
<div class="container">
    <div class="main-body">
    
          <!-- Breadcrumb -->
          <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
            <div class="col-md-12">
                     <form method="post">  
                      
                          <input type="submit" name="generate_pdf" class="btn btn-success" value="Download">  
                     </form> 
                     </div>
            </ol>
          </nav>
          <!-- /Breadcrumb -->
    
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                     <img class="prof" src="images/<?php echo $image; ?>" name="image" width="20">

                     

                    <div class="mt-3">
                      <h4><h5>Reg.Number: <?php echo $regNo; ?></h5></h4>
                                          </div>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name: </h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $name?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Gender</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $gender ?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Date of Birth </h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $dob ?>
                    </div>
                  </div>

                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Religin</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $mkoa ?>
                    </div>
                  </div>

                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Distrit</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $wilaya ?>
                    </div>
                  </div>


                  <hr>


                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Address</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $shehia ?>
                    </div>
                  </div>
                  <hr>


                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">School Name</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $school ?>
                    </div>
                  </div>


                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Level Study</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $level ?>
                    </div>
                  </div>


                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Class Name</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $class ?>
                    </div>
                  </div>



                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Type</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $type ?>
                    </div>
                  </div>


                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Maradhi</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $maradhi ?>
                    </div>
                  </div>


                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Gudan</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $mlezi ?>
                    </div>
                  </div>


                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Disability</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $ulemavu ?>
                    </div>
                  </div>
                  

                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Phone Number</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $sim ?>
                    </div>
                  </div>
                  <hr>

                  

                

                </div>
              </div>


              

            </div>
          </div>

        </div>
    </div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>

