<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


<?php
  include('../db/db.php');



$id=$_GET['id'];
$result=mysqli_query($conn,"SELECT * FROM user WHERE id=$id");
while($res=mysqli_fetch_array($result)){
  $name=$res['name'];
  $gender=$res['gender'];
  $simu=$res['simu'];
  $user_type=$res['user_type'];
  $email=$res['email'];
  $password=$res['password'];
  $image=$res['image'];
  
    }
?>
 


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">

       <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>Views Infromation</h1>
          <p>Details Ofice Member</p>
        </div>

        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Infromation</li>
        </ul>
      </div>
      
<div class="container">
    <div class="main-body">
    
          <!-- Breadcrumb -->
          <nav aria-label="breadcrumb" class="main-breadcrumb">
            
          </nav>
          <!-- /Breadcrumb -->
    
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                     <img class="prof" src="staff/<?php echo $image; ?>" name="image" width="20">


                    <div class="mt-3">
                      <h4><h5>Name: <?php echo $name; ?></h5></h4>
                                          </div>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">

                  <h3 style="color: blue">Staff Infromation Details</h3>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name: </h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $name?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Gender</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $gender ?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Email</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $email ?>
                    </div>
                  </div>

                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Phone Number</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $simu ?>
                    </div>
                  </div>


                  <hr>


                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Password</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $password ?>
                    </div>
                  </div>
                  <hr>


                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">User Type</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $user_type ?>
                    </div>
                  </div>


                  <hr>
                 

                </div>
              </div>


              

            </div>
          </div>

        </div>
    </div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>

