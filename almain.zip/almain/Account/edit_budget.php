<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


 <?php include('../db/db.php'); 

 $id=$_GET['id'];
 $tia=mysqli_query($conn,"SELECT * FROM budget WHERE id=$id");
  while($res=mysqli_fetch_array($tia)){
  $name=$res['name'];
  $amount=$res['amount'];
  $comment=$res['comment'];
  
  }
?>





 <?php
 //session_start();
  include('../db/db.php');



?>





 


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-eye"></i> Staff Details</h1>
          <p>Staff Infromation</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item">Staff Infromation</li>
          <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
        </ul>
      </div>



      <?php
if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $amount = $_POST['amount'];
    $comment = $_POST['comment'];
    

  $tia=mysqli_query($conn, "UPDATE budget SET name='$name', amount='$amount', comment='$comment' WHERE id=$id");

  
  if($tia){

    echo "<script>alert('Umefanikiwa Kubadili Taarifa');</script> . <script>window.location = 'bajeti.php';</script>";
  
  }
  else{
    echo "<script>alert('Hujafanikiwa Kubadili Taarifa');</script> . <script>window.location = 'bajeti.php';</script>";
  }
  
}



?>





  <!-- Hapa Ni Kuweka vitu Unavo Vitaka -->

  <form action="" method="POST" enctype="multipart/form-data"> 

  <div class="container rounded bg-white mt-5">
    <div class="row">

        
        <div class="col-md-12">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="d-flex flex-row align-items-center back">
  

                       
                    </div>
                    <h6 class="text-right">Edit Details</h6>
                    </div>

                <hr>

        <div class="form-row">

                               
                <div class="col-md-6 mb-4">
                  <label>Full Name</label>
                  <input type="text" class="form-control" name="name" required="" value="<?php echo $name; ?>">

                </div>


               
                <div class="col-md-6 mb-4">
                  <label>Amount</label>
                  <input type="text" class="form-control" name="amount" required="" value="<?php echo $amount; ?>">

                </div>


                <div class="col-md-12 mb-4">
                  <label>Description<b style="color: red">*</b></label>
                 <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Write a new comment " name="comment"></textarea>
                  
                </div>



                
       <div class="form-grop">
          <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
          <input type="submit" name="submit" value="Update" class="btn btn-primary">
       </div>
 
                
        </div>
    </div>
</div>
</form>





 


</div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>
