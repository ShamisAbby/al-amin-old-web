<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


 <?php include('../db/db.php'); 

 $id=$_GET['id'];
 $tia=mysqli_query($conn,"SELECT * FROM mkopo WHERE id=$id");
  while($res=mysqli_fetch_array($tia)){
  $regNo=$res['regNo'];
  $name=$res['name'];
  $gender=$res['gender'];
  $address=$res['address'];
  $amount=$res['amount'];
  $sim=$res['sim'];
  $pay_amount = $res['pay_amount'];
    }
?>





 <?php
 //session_start();
  include('../db/db.php');



?>





 


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-eye"></i> Member Details</h1>
          <p>Taarifa za Mwanachama</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item">Taarifa za Mwanachama</li>
          <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
        </ul>
      </div>



      <?php
if(isset($_POST['submit'])){
    $id=$_GET['id'];
    $pay_amount = $_POST['pay_amount'];
     

  //$tia=mysqli_query($conn, "INSERT INTO mkopo(pay_amount) VALUES('$pay_amount')");

   $tia=mysqli_query($conn, "UPDATE mkopo SET pay_amount='$pay_amount'WHERE id=$id");


  
  if($tia){

    echo"<div class= 'alert alert-success'><center><strong><b><h4> The payment of member has successfully <h4></strong></b></div>";
  
  }
  else{
    echo"<div class= 'alert alert-success'><center><strong><b> Not successfully!!</strong></b></div>"; 
  }
  
}



?>


  <!-- Hapa Ni Kuweka vitu Unavo Vitaka -->

  <form action="" method="POST"> 

  <div class="container rounded bg-white mt-5">
    <div class="row">

        <div class="col-md-4 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
              <img class="prof" src="sampo.jpg" width="90">


      <h4 class="ptext">
       <h5>Registration Number: <?php echo $regNo; ?></h5>
       <div class="no">
      <div class="col-md-8"><input type="text"  value="<?php echo $regNo?>"></div>
    </div>
     </h4>

              <div class="line"></div>

            </div>
        </div>



        <div class="col-md-8">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="d-flex flex-row align-items-center back">
  

                       
                    </div>
                    <h6 class="text-right">Member Details</h6>
                    </div>

                <hr>

        <div class="form-row">

                <div class="col-md-6 mb-4">
                  <label>Number of Member</label>
                  <input type="text" class="form-control" name="regNo" value="<?php echo $regNo; ?>" readonly="">

                </div>
                
                <div class="col-md-6 mb-4">
                  <label>Full Name</label>
                  <input type="text" class="form-control" name="name" value="<?php echo $name; ?>" readonly="">

                </div>

                <div class="col-md-6 mb-4">
                  <label>Gender</label>
                  <input type="text" class="form-control" name="gender" value="<?php echo $gender; ?>"readonly="">

                </div>


                <div class="col-md-6 mb-4">
                  <label>Address</label>
                  <input type="text" class="form-control" name="address" value="<?php echo $address; ?>"readonly="">

                </div>


            <div class="col-md-6 mb-4">
                  <label>Phone Number</label>
                  <input type="text" class="form-control" name="sim" value="<?php echo $sim; ?>"readonly="">

                </div>


                <div class="col-md-6 mb-4">
                  <label>Amount</label>
                  <input type="text" class="form-control" name="amount" value="<?php echo $amount; ?>"readonly="">
                </div>


                <div class="col-md-6 mb-4">
                  <label>Amount Pay</label>
                  <input type="text" class="form-control" name="amount" value="<?php echo $pay_amount; ?>"readonly="">
                </div>

                <div class="col-md-6 mb-4">
                  <label>Amount Pay</label>
                  <input type="text" class="form-control" name="pay_amount" value="<?php echo $pay_amount; ?>">
                </div>

                 <?php
                  $m=$amount-$pay_amount;
                  ?>

                <div class="col-md-12 mb-4">
                  <label>Amount Remain</label>
                  <input type="text" class="form-control" readonly="" value="<?php echo $m; ?>">
                 
                </div>



      

       <div class="form-grop">
          <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
          <input type="submit" name="submit" value="Save" class="btn btn-primary">
       </div>
 
                
        </div>
    </div>
</div>
</form>





 


</div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>


<script>
function show(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_wilaya").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_wilaya").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_mikoa.php?r="+str,true);
            xmlhttp.send();
  }

}

</script>


<script>
function ww(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_class").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_class").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_school?q="+str,true);
            xmlhttp.send();
  }

}

</script>