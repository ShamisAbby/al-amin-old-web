<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>




<?php
  include('../db/db.php');
 
?>


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i> Registertion Form</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item"><a href="#">Form Components</a></li>
        </ul>
      </div>




      <div class="col-lg-12">

            <div class="panel panel-default">

<?php
$mgs=0;

if (isset($_POST['submit'])) { // if save button on the form is clicked
    
       $name = $_POST['name'];
       $amount = $_POST['amount'];
       $comment = $_POST['comment'];

  $check = mysqli_query($conn, "SELECT name FROM donater WHERE name = '$name' ");
  if(mysqli_num_rows($check) > 0){
    echo"<div class= 'alert alert-success'><center><strong><b><h4> The Infomation has already to received a system! <i style='color:black'> </strong><h4></i></b></div>";
}


else{
               

$sql = mysqli_query($conn,"INSERT INTO budget(name,amount,comment)
     VALUES('$name','$amount','$comment')");



 if($sql){
                 $mgs=1;
                }
             else{
                  echo"<div class= 'alert alert-success'><center><strong><h5>TAARIFA ULIZO ZIINGIZA ZIMESHAHIFADHIWA</strong></h5></div>";
                }
             }

            ?>
<?php


    }




?>


</div>

<a href="bajeti.php" class="btn btn-success">Back</a>

<br>
<br>
<div class="tile">



  <?php if($mgs){

  ?>

  <div class="alert alert-success">
    <center><strong><h5>UMEFANIKIWA!</strong> KUINGIZA TAARIFA;</h5>

  </div>

<?php   }?>





       <form action="add_budget.php" method="POST">
              <div class="form-row">
              

              
                <div class="col-md-6 mb-4">
                  <label>Budget Name <b style="color: red">*</b></label>
                  <input type="text" class="form-control" placeholder="Budget Name" name="name" required="">

                </div>


                <div class="col-md-6 mb-4">
                  <label>Amount <b style="color: red">*</b></label>
                  <input type="number" class="form-control" placeholder="Amount" name="amount" required="">

                </div>


                <div class="col-md-12 mb-4">
                  <label>Description<b style="color: red">*</b></label>
                 <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Write a comment....." name="comment"></textarea>
                  
                </div>

                         
                
                                 
                 <br>
                <br>
               
                <div class="form-grop">
                    <input type="submit" name="submit" value="Send" class="btn btn-primary">
               </div>

               </form>

</div>
</div>

<br>

</div>

</main>

    <?php include('js.php') ?>



<!--
  Kuvuta Mikoa Katika Data bases
-->


  

    
  </body>
</html>