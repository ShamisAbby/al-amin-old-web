<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>



<?php
include_once("../db/db.php");
 
//include_once 'dbConfig.php'; 
 
// Fetch records from database 
$query = $conn->query("SELECT * FROM wanafunzi"); 

if($query->num_rows > 0){ 
    $delimiter = ","; 
    $filename = "file" . date('d-m-Y') . ".csv"; 
     
    // Create a file pointer 
    $f = fopen('php://memory', 'w'); 
     
    // Set column headers 
    $fields = array('Reg Number','Name','Date of Birth', 'Gender', 'Religion', 'Distrit','Address','Phone Number','School' ,'Level', 'Class', 'Member', 'Desise', 'Parent' ,'Gudain','Disability'); 
    fputcsv($f, $fields, $delimiter); 
     
    // Output each row of the data, format line as csv and write to file pointer 
    while($row = $query->fetch_assoc()){ 
        $size = ($row['size'] == 0); 
        $lineData = array($row['regNo'], $row['name'], $row['dob'], $row['gender'], $row['mkoa'], $row['wilaya'], $row['shehia'],$row['sim'], $row['school'], $row['level'], $row['class'], $row['type'], $row['maradhi'],$row['mzazi'], $row['mlezi'], $row['ulemavu']); 
        fputcsv($f, $lineData, $delimiter); 
    } 
     
    // Move back to beginning of file 
    fseek($f, 0); 
     
    // Set headers to download file rather than displayed 
    header('Content-Type: text/csv'); 
    header('Content-Disposition: attachment; filename="' . $filename . '";'); 
     
    //output all remaining data on a file pointer 
    fpassthru($f); 
} 
exit; 
 
?>