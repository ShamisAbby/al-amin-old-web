<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>



<?php
 if(isset($_POST["generate_pdf"]))  
 {  
  
      require_once('../tcpdf/tcpdf.php');  
      $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
      $obj_pdf->SetCreator(PDF_CREATOR);  
      $obj_pdf->SetTitle("Al-Amin Relief Foundation");  
      $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
      $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
      $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
      $obj_pdf->SetDefaultMonospacedFont('Times');  
      $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
      $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);  
      $obj_pdf->setPrintHeader(false);  
      $obj_pdf->setPrintFooter(false);  
      $obj_pdf->SetAutoPageBreak(TRUE, 10);  
      $obj_pdf->SetFont('Times', '', 11);  
      $obj_pdf->AddPage(); 

      $obj_pdf->SetFont("Times","B",11);

             $obj_pdf->Cell(50,10,"Al-Amin Relief Foundation",60,0,"C");
             $obj_pdf->Ln(7);
             $obj_pdf->Cell(77,10,"Tel: +255 778 753  384 / +255 776 529 210",60,0,"C");
             $obj_pdf->Ln(7);
             $obj_pdf->Cell(65,10,"E-Mail:info@alaminfoundation.or.tz",60,0,"C");
             $obj_pdf->Ln(7);
             $obj_pdf->Cell(54,10,"Website:alaminfoundation.or.tz",60,0,"C");
             $obj_pdf->Ln(7);
             $obj_pdf->Line(12,45,200,45);

      $obj_pdf->Image("almin.jpeg",170,17,30);
      $obj_pdf->Ln(30);

      $obj_pdf->SetFont("Times","B",18);
      $obj_pdf->SetTextColor(153,0,153);
      $obj_pdf->Cell(185,10,"Budget of Al-Amin Relief Foundation",60,0,"C");
      $obj_pdf->Ln(30);
      $obj_pdf->SetFont("Times","",12);
      $obj_pdf->SetTextColor(0,0,0);

      

      $content = '';  
      $content .= ' 





            <table border="1" cellspacing="0" cellpadding="1">  
           <tr> 
                <th>S/No</th>  
                <th><b>Budget Name </b></th>
                <th width="20%"><b>Amount</b></th>  
                <th><b>Date</b></th> 
                 <th><b>Total Amount</b></th> 
                
           </tr>  
      ';
        
      $content .= fetch_data();  
      $content .= '</table>';  
      $obj_pdf->writeHTML($content);  
      $obj_pdf->Output('file.pdf', 'I'); 


 } 

 ?>



 <?php  
 function fetch_data()  
 {  
      $output = '';  
      include("../db/db.php");
      $sql = "SELECT * FROM budget";  
      $sn=0;
      $result = mysqli_query($conn, $sql);  
      while($row = mysqli_fetch_array($result))  
      {      
      $sn++; 
      $output .= '<tr>    <td>'.$sn.'</td>  
                          <td>'.$row["name"].'</td>  
                          <td>'.$row["amount"].'</td>  
                          <td>'.$row["date"].'</td> 
                          
                     </tr>  
                          ';  
      }  


      return $output;  

 }  


?>






<?php
include("../db/db.php");
?>


<?php include('header.php') ?>



  <body class="app sidebar-mini">
    <!-- Navbar-->
    

<?php include('topmenu.php') ?>



    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
   

   <?php include('navbar.php') ?>




    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>Views Member</h1>
          <p>Watu walio Sajiliwa katika mfumo</p>
        </div>

        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Tables</li>
          <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
        </ul>
      </div>

      <div class="col-lg-12">


         
    </div>



    
 


      <div class="row">
        <div class="col-md-12">
          <div class="tile">
                                

                 <div class="col-md-12">
                     
                     </div>

                     <div class="col-md-12">
                  <div class="form-row">
                 <div class="col-md-1.5 mb-2">
                     <form method="post">  
                      
                          <input type="submit" name="generate_pdf" class="btn btn-success" value="Download">  
                     </form>
                     </div>

                     <div class="col-md-1.5 mb-2">  

                     <a class="btn btn-success" href="add_budget.php">Add Budget </a>

                     </div>

            <div class="col-md-1.5 mb-2">
                     <?php
             include("../db/db.php");
                $sss = "SELECT SUM(amount) as sr FROM budget";
                $ddd=mysqli_query($conn,$sss);
                $rrr=mysqli_query($conn,"SELECT * FROM budget");

                             
                          while($r=mysqli_fetch_assoc($ddd))
                            {
                              echo "<h4 style='font-size:18px'>".'Total:'.$r['sr'].'Tsh';
                            }
            ?>
            </div>

                   </div>
                 </div>


                   <hr>
            <div class="tile-body">
              <div class="table-responsive">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th style="font-size: 15px">S/n</th>
                      <th style="font-size: 15px">Budget Name</th>
                      <th style="font-size: 15px">Amount</th>
                      <th style="font-size: 15px">Comment</th>
                      <th style="font-size: 15px">Date</th>
                      <th style="font-size: 15px">Views</th>
                      <th style="font-size: 15px">Update</th>
                      <th style="font-size: 15px">Remove </th>
                     </tr>
                  </thead>
                                               
                  </tbody>


                  <?php
                
       $data = mysqli_query($conn, "SELECT * FROM budget");
            $kuesabu=0;
            $kuesabu ++; 

            $rows= mysqli_num_rows($data);

            if(mysqli_num_rows($data) > 0){
              while($row=mysqli_fetch_array($data))
            {
             ?>

                   <tr>
                    <td>
                          <?php echo $kuesabu  ?>
                      </td>


                       
                      <td>
                          <?php echo $row['name'];  ?>
                      </td>

                     
                      <td>
                          <?php echo $row['amount'];  ?>
                      </td>

                      <td>
                          <?php echo $row['comment'];  ?>
                      </td>

                       <td>
                          <?php echo $row['date'];  ?>
                      </td>


                    


                      <td>
                         <a href="views_user.php?id=<?php echo $row["id"]; ?>" title="edit" class="delete" onclick="return confirm('Are you sure you want to Views?') "><i class='fa fa-eye' style="font-size: 20px; color: green"></i></a>
                                           
                      </td>


                      <td>
                        <a href="edit_budget.php?id=<?php echo $row["id"]; ?>" title="edit" class="delete" onclick="return confirm('Are you sure you want to Edit?') "><i class='fa fa-edit' style="font-size: 20px; color: blue"></i></a>
                      </td>

                       
                                   
                                    

                   
                    <td>
                    
                   <a href="delate_budget?id=<?php echo $row["id"]; ?>" title="delete" class="delete" onclick="return confirm('Are you sure you want to delete?') "><i class="fa fa-trash" style="font-size:18px; color: red"></i></a>

                    <!--<a href="delete_yatima.php?id=<?php// echo $row["id"]; ?>"><i class="fa fa-trash" style="font-size:17px"></i></a>-->
                    </td>

                

                      
                    </tr>

                     <?php

        $kuesabu ++;
      }
    }


?>


                 
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    

    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>


     
  </body>
</html>