<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


<?php
include("../db/db.php");
?>


<?php include('header.php') ?>



  <body class="app sidebar-mini">
    <!-- Navbar-->
    

<?php include('topmenu.php') ?>



    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
   

   <?php include('navbar.php') ?>




    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>Views Member</h1>
          <p>Watu walio Sajiliwa katika mfumo</p>
        </div>

        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Tables</li>
          <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
        </ul>
      </div>

      <div class="col-lg-12">
        
    </div>




<!-- Button to Import and export -->

    <div class="col-lg-12">
        <div class="form-row">
    


   <div class="col-md-2 mb-2">
 

      </div>
    </div>

 
        <br>


<form action="" method="POST">
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <div class="table-responsive">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th style="font-size: 15px">S/n</th>
                      <th style="font-size: 15px">Reg No</th>
                      <th style="font-size: 15px">Name</th>
                      <th style="font-size: 15px">D.of. B</th>
                      <th style="font-size: 15px">Gender</th>
                      <th style="font-size: 15px">Address</th>
                      <th style="font-size: 15px">Phone</th>
                      <th style="font-size: 15px">Remove</th>
                     </tr>
                  </thead>
                  <tbody>


        

    <?php
      $mgs=0;

?>

       <?php
          if($mgs){

  ?>

  <div class="alert alert-success">
    <strong>Umefanikiwa KuBadili Taarifa</strong>

  </div>

    <?php   
  }



       ?>


<?php
$data = mysqli_query($conn, "SELECT * FROM Wanafunzi WHERE sadaka='Already'");
$kuesabu=0;
$sn=0;

//$rows= mysqli_num_rows($data);

if(mysqli_num_rows($data) > 0){
   
  
while($row=mysqli_fetch_array($data))
{
  $sn++;
 ?>


    <tr>

     <td>
          <?php echo $sn;  ?>
     </td> 

     <td>
          <?php echo $row['regNo'];  ?>
     </td>


     <td>
          <?php echo $row['name'];  ?>
      </td>


      <td>
          <?php echo $row['dob'];  ?>
      </td>


       <td>
          <?php echo $row['gender'];  ?>
      </td>


      <td>
          <?php echo $row['shehia'];  ?>
      </td>


      <td>
          <?php echo $row['sim'];  ?>
      </td>

      <td>

        <select class="form-control" name="sadaka[<?php echo $kuesabu; ?>]" required="">
          <option value="0">Remove</option>
        </select>
          
        </td>
        
      <input type="submit" class="btn btn-primary" value="Send" name="send" required="">
      <br><br>
      </tr>
    
        <?php

        $kuesabu ++;



      }
}


  else{


    echo"<div class= 'alert alert-success'><center><strong><b>Hakuna Taarifa Zitakazo Badilishwa</strong></b></div>";
  }



?>
   </tbody>
  </table>

   
</form>           

</div>




<?php
$mgs=0;

if(isset($_POST['send'])){

  foreach($_POST['sadaka'] as $id=>$sadaka){

    
  
    //$majibu=mysqli_query($conn,"INSERT INTO Wanafunzi(sadaka,aina_sadaka) VALUES('0','0')");
   $majibu=mysqli_query($conn,"UPDATE Wanafunzi SET sadaka='$sadaka' AND aina_sadaka='0'");
    if($majibu){
    $mgs=1;
    }
    
   
  }
}



?>

                                                       
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    

    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>


     
  </body>
</html>