
<?php
include("../db/db.php");
$id=$_GET['id'];
$con=mysqli_query($conn,"DELETE FROM wanafunzi WHERE id=$id ");
if($con){
	header("location:table-data-table.php");	
}
else{
	echo "failed";
}

?>