<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


<?php
include '../db/db.php';
if(isset($_POST["bulk"])){
    
    echo $filename=$_FILES["file"]["tmp_name"];
    

    $file = $_FILES['file']['tmp_name'];
    $handle = fopen($file, "r");
    $c = 0;
    $count = 0;
    while (($filesop = fgetcsv($handle, 1000, ",")) !== false)
    {   
        //$id = $filesop[0];
        $regNo = $filesop[0];
        $name = $filesop[1];
        $dob = $filesop[2];
        $gender = $filesop[3];
        $mkoa = $filesop[4];
        $wilaya = $filesop[5];
        $shehia = $filesop[6];
        $sim =$filesop[7];
        $school =$filesop[8];
        $level =$filesop[9];
        $class =$filesop[10];
        $type =$filesop[11];
       // $maradhi =$filesop[15];
        //$mzazi =$filesop[16];
        //$mlezi =$filesop[21];
        //$ulemavu =$filesop[22];


        

        
        $count++;
        if ($count > 1)
        {
            //It wiil insert a row to our subject table from our csv file`
            $query = "INSERT INTO wanafunzi(regNo,name,dob,gender,mkoa,wilaya,shehia,sim,school,level,class,type)"."VALUES('$regNo','$name','$dob','$gender','$mkoa','$wilaya','$shehia','$sim','$school','$level','$class','$type')";
            $conn->query($query) or die('ber are Used');

            $c = $c + 1;

        }
      }


       if (isset($c))
    {
      
      echo "<script type=\"text/javascript\">
            alert(\"CSV File has been successfully Imported.\");
            window.location = \"table-data-table.php\"
          </script>";
    }
    else
    {
       echo "<script type=\"text/javascript\">
             alert(\"Invalid File:Please Upload CSV File.\");
              window.location = \"index.php\"
            </script>";
    }




  }  
?>     