<?php
     require("fpdf.php");
     $pdf = new FPDF();

    if(isset($_POST['create'])){

       $regNo = $_POST['regNo'];
       $name = $_POST['name'];
       $dob = $_POST['dob'];
       $gender = $_POST['gender'];
       $mkoa = $_POST['mkoa'];
       $wilaya = $_POST['wilaya'];
       $shehia =  $_POST['shehia'];
       $sim = $_POST['sim'];
       $school =  $_POST['school'];
       $level =  $_POST['level'];
       $class =  $_POST['class'];
       $type =  $_POST['type'];
       $maradhi =  $_POST['maradhi'];
       $mzazi = $_POST['mzazi'];
       $mlezi = $_POST['mlezi'];
       $mzamini = $_POST['mzamini'];

          $pdf->AddPage();
          $pdf->SetFont("Times","B",20);

       $pdf->Image("almin.jpeg",10,10,30);
       $pdf->SetX(250);
       $pdf->Ln();
       $pdf->SetY(45);
       $pdf->Cell(0,0,"Member Information");
       $pdf->Line(10,50,75,50);
       $pdf->Ln(10);
       $pdf->Cell(70,10,"Al-Amin Relief Foundation",60,0,"C");


     
       

      
         $pdf->SetY(90);
         $pdf->SetFont("Times","B",15);
         $pdf->Cell(45,10,"Regstration:",0,0);
         $pdf->Cell(45,10,"$regNo",0,0);
         $pdf->Cell(35,10,"Full Name:",0,0);
         $pdf->SetFont("Times","",15);
         $pdf->Cell(30,10,"$name",0,0);
         $pdf->Ln();
         $pdf->Line(10,100,200,100);

         
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(45,20,"Gender:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(45,20,"$gender",0,0);
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(35,20,"D.O.B:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(35,20,"$dob",0,0);
        $pdf->Ln();
        $pdf->Line(10,115,200,115);

        
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(45,20,"Religion:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(45,20,"$mkoa",0,0);
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(35,20,"Destrit:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(35,20,"$wilaya",0,0);
        $pdf->Ln();
        $pdf->Line(10,135,200,135);

        
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(45,20,"Address:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(45,20,"$shehia",0,0);
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(35,20,"School:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(35,20,"$school",0,0);
        $pdf->Ln();
        $pdf->Line(10,155,200,155);




        $pdf->SetFont("Times","B",15);
        $pdf->Cell(45,10,"Level Study:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(45,10,"$level",0,0);
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(35,10,"Class Name:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(35,10,"$class",0,0);
        $pdf->Ln();
        $pdf->Line(10,170,200,170);



        
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(45,20,"Member:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(45,20,"$type",0,0);
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(35,20,"Disease:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(35,20,"$maradhi",0,0);
        $pdf->Ln();
        $pdf->Line(10,190,200,190);

        $pdf->SetFont("Times","B",15);
        $pdf->Cell(45,20,"Dead Parent:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(45,20,"$mzazi",0,0);
        $pdf->SetFont("Times","B",15);
        $pdf->Cell(35,20,"Guardian:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(35,20,"$mlezi",0,0);
        $pdf->Ln();
        $pdf->Line(10,210,200,210);


        $pdf->SetFont("Times","B",15);
        $pdf->Cell(45,10,"Sponser:",0,0);
        $pdf->SetFont("Times","",15);
        $pdf->Cell(45,10,"$mzamini",0,0);
        $pdf->Line(10,220,200,220);


               

     $pdf->Output();

}
  


?>