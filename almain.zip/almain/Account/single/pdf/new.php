<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>

<?php
      require("fpdf.php");
     $pdf = new FPDF();
    include('../../../db/db.php');

 ?>
 
 <?php    



      if(isset($_POST['submit'])){

       $regNo = $_POST['regNo'];

      
       //$q= "SELECT * FROM wanafunzi WHERE regNo='$regNo'";
      // $q=mysqli_query($conn,"SELECT * FROM wanafunzi WHERE regNo='$regNo'");

       $sql = mysqli_query($conn, "SELECT * FROM wanafunzi WHERE  regNo =$regNo");
 			    
 				$row=mysqli_fetch_assoc($sql);
 				//$row = mysqli_query($conn,$sql);
 				
 				$pdf->AddPage();
                $pdf->SetFont("Times","",12);

                
			       $pdf->Cell(50,10,"Al-Amin Relief Foundation",60,0,"C");
			       $pdf->Ln(7);
			       $pdf->Cell(20,10,"P.O.BOx:",60,0,"C");
			       $pdf->Ln(7);
			       $pdf->Cell(77,10,"Tel: +255 778 753  384 / +255 776 529 210",60,0,"C");
			       $pdf->Ln(7);
			       $pdf->Cell(65,10,"E-Mail:info@alaminfoundation.or.tz",60,0,"C");
			       $pdf->Ln(7);
			       $pdf->Cell(54,10,"Website:laminfoundation.or.tz",60,0,"C");
			       $pdf->Ln(7);
			       $pdf->Line(12,45,200,45);

			       $pdf->Image("almin.jpeg",170,17,30);
			       
                                      
                   
                   $pdf->SetFont("Times","B",18);
			       $pdf->Cell(185,10,"BASIC INFORMATION OF MEMBER",60,0,"C");

                    $pdf->Ln(20);  
			        $pdf->Cell(58,10,"Pasanal Information",60,0,"C");
			        $pdf->Line(12,73,67,73);
			        $pdf->Line(0,85,250,85);


			        $pdf->Ln(10);
			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(30,10,"Full Name:",60,0,"C");
			        $pdf->Ln(5);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(112,0,$row['name'],0,0,'C',0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(-23,0,"Gender:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",15);
			        $pdf->Cell(235,0,$row['gender'],0,0,'C',0);
			        $pdf->Line(0,115,250,115);

                      
                      $pdf->Ln(0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(270,0,"D.O.B:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(320,0,$row['dob'],0,0,'C',0);



			        $pdf->Ln(5);




			        $pdf->Ln(10); 
			        $pdf->SetFont("Times","B",18); 
			        $pdf->Cell(58,10,"Resident information",60,0,"C");
			        $pdf->Line(12,73,67,73);

			        $pdf->Ln(10);
			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(20,10,"Region:",60,0,"C");
			        $pdf->Ln(5);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(110,0,$row['mkoa'],0,0,'C',0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(-23,0,"District:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(235,0,$row['wilaya'],0,0,'C',0);
			        $pdf->Line(0,150,250,150);

                      
                      $pdf->Ln(0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(270,0,"Address:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(320,0,$row['shehia'],0,0,'C',0);



			        $pdf->Ln(20); 
			        $pdf->SetFont("Times","B",18); 
			        $pdf->Cell(58,10,"School information",60,0,"C");
			        $pdf->Line(12,73,67,73);

			        $pdf->Ln(10);
			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(20,10,"School:",60,0,"C");
			        $pdf->Ln(5);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(110,0,$row['school'],0,0,'C',0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(-23,0,"Level:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(235,0,$row['level'],0,0,'C',0);
                      
                      $pdf->Ln(0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(270,0,"Class:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(320,0,$row['class'],0,0,'C',0);


			        $pdf->Ln(30); 
			        $pdf->SetFont("Times","B",18); 
			        $pdf->Cell(58,10,"Parental Information",60,0,"C");
			        $pdf->Line(12,73,67,73);

			        $pdf->Ln(10);
			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(30,10,"Death of Parent:",60,0,"C");
			        $pdf->Ln(5);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(110,0,$row['mzazi'],0,0,'C',0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(-5,0,"Guardian:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(265,0,$row['mlezi'],0,0,'C',0);
			        $pdf->Line(0,193,250,193);
                      
                    $pdf->Ln(0);




                    $pdf->Ln(20); 
			        $pdf->SetFont("Times","B",18); 
			        $pdf->Cell(58,10,"Disabilty and Desise",60,0,"C");
			        $pdf->Line(12,73,67,73);

			        $pdf->Ln(10);
			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(20,10,"Disabilty:",60,0,"C");
			        $pdf->Ln(5);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(110,0,$row['ulemavu'],0,0,'C',0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(-23,0,"Desise:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(235,0,$row['maradhi'],0,0,'C',0);
			        $pdf->Line(0,228,250,228);
                      
                      $pdf->Ln(0);

			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(270,0,"Member:",60,0,"C");
			        $pdf->Ln(0);
			        $pdf->SetFont("Times","",12);
			        $pdf->Cell(320,0,$row['type'],0,0,'C',0);



			        $pdf->Ln(10); 
			        $pdf->SetFont("Times","B",18); 
			        $pdf->Cell(58,10,"For Office Only",60,0,"C");
			        $pdf->Line(12,73,67,73);

			        $pdf->Ln(10);
			        $pdf->SetFont("Times","B",12);
			        $pdf->Cell(90,10,"General Officer",60,0,"C");
			        $pdf->Cell(120,10,"Accountes  Officer",60,0,"C");
			        $pdf->Ln(8);
			        $pdf->Cell(90,10,"...................................................................",60,0,"C");
;
			        $pdf->Cell(120,10,"...................................................................",60,0,"C");
			        $pdf->Ln(10);

			        $pdf->Cell(90,10,"_________________________________",60,0,"C");
			        $pdf->Cell(120,10,"_________________________________",60,0,"C");
			        $pdf->Ln(5);
			        $pdf->SetFont("Times","",12);
			        
              


 
 $pdf->output();

 }

 else{
 	echo "Hamna Kitu";
 }

?>