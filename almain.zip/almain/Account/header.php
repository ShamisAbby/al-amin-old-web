<!DOCTYPE html>
<html lang="en">
  <head>
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>Al-Amin Relief Foundation</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        .app-sidebar__user img{
            width: 60px; 
            height: 70px;
        }

    .picha img{
        margin-top: 2px;
        width: 160px; 
        height: 185px;
        background-image: url("sampo.jpg");
        border-radius: 5px;
    }

   .picha{
    
    width: 180px;
    height: 190px;
    border-radius: 10px;

   }

   

   .picha1 img{
        margin-top: 2px;
        width: 160px; 
        height: 185px;
        background-image: url("sampo.jpg");
        border-radius:;
    }

   .picha1{
    
    width: 180px;
    height: 190px;
    border-radius: 10px;

   }

   .prof{
    width: 230px;
    height: 230px;
    border-radius: 10px;
    cursor: pointer;
   }

   



   
   .ptext{
    margin-top: 15px;
       }

    .ptext input{
           width: 70px;

       } 

       .no input{
        display: none;
       }  

    .line{
        width: 350px;
        background: blue;
        height: 5px;
    }   

        
    </style>
  </head>