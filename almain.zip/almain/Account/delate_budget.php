
<?php
include("../db/db.php");
$id=$_GET['id'];
$con=mysqli_query($conn,"DELETE FROM budget WHERE id=$id ");
if($con){
	header("location:bajeti.php");	
}
else{
	echo "failed";
}

?>