<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


  <script type='text/javascript'>
      function preview_image(event) 
      {
       var reader = new FileReader();
       reader.onload = function()
       {
        var output = document.getElementById('output_image');
        output.src = reader.result;
       }
       reader.readAsDataURL(event.target.files[0]);
      }
  </script>


   <script type='text/javascript'>
      function preview(event) 
      {
       var reader = new FileReader();
       reader.onload = function()
       {
        var output = document.getElementById('output');
        output.src = reader.result;
       }
       reader.readAsDataURL(event.target.files[0]);
      }
  </script>




<?php
  include('../db/db.php');
 
?>


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i> Registertion Form</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item"><a href="#">Form Components</a></li>
        </ul>
      </div>




      <div class="col-lg-12">

            <div class="panel panel-default">

<?php
$mgs=0;

if (isset($_POST['submit'])) { // if save button on the form is clicked
    // name of the uploaded file
      $image = $_FILES['image']['name'];
      $page1 = $_FILES['page1']['name'];
      $page2 = $_FILES['page2']['name'];
      $page3 = $_FILES['page3']['name'];
      $m_image = $_FILES['m_image']['name'];

       $regNo = $_POST['regNo'];
       $name = $_POST['name'];
       $dob = $_POST['dob'];
       $gender = $_POST['gender'];
       $mkoa = $_POST['mkoa'];
       $wilaya = $_POST['wilaya'];
       $shehia =  $_POST['shehia'];
       $address =  $_POST['address'];
       $sim = $_POST['sim'];
       $idNo =  $_POST['idNo'];
       $m_name =  $_POST['m_name'];
       $m_gender =  $_POST['m_gender'];
       $uhusiano =  $_POST['uhusiano'];
       $m_id =  $_POST['m_id'];
       $m_sim = $_POST['m_sim'];
       $s_name =  $_POST['s_name'];
       $s_mkoa = $_POST['s_mkoa'];
       $s_wilaya = $_POST['s_wilaya'];
       $s_shehia =  $_POST['s_shehia'];
       $anapoishi = $_POST['anapoishi'];
       $kiwango = $_POST['kiwango'];
        
 


    // destination of the file on the server
    $destination1 = 'mzamini/' . $image;
    $destination2 = 'mzamini/' . $page1;
    $destination3 = 'mzamini/' . $page2;
    $destination4 = 'mzamini/' . $page3;
    $destination5 = 'mzamini/' . $m_image;



    // get the file extension
    $extension = pathinfo($image, PATHINFO_EXTENSION);
    $extension = pathinfo($page1, PATHINFO_EXTENSION);
    $extension = pathinfo($page2, PATHINFO_EXTENSION);
    $extension = pathinfo($page3, PATHINFO_EXTENSION);
    //$extension = pathinfo($m_image, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file1 = $_FILES['image']['tmp_name'];
    $file2 = $_FILES['page1']['tmp_name'];
    $file3 = $_FILES['page2']['tmp_name'];
    $file4 = $_FILES['page3']['tmp_name'];
    $file5 = $_FILES['m_image']['tmp_name'];
    $size = $_FILES['image']['size'];
    $size = $_FILES['page1']['size'];
    $size = $_FILES['page2']['size'];
    $size = $_FILES['page3']['size'];
    $size = $_FILES['m_image']['size'];

    
   if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
       // echo "You file extension must be .zip, .pdf or .docx";

        echo"<div class= 'alert alert-success'><center><strong><h4>Your file extension must be (zip) , (pdf) OR (docx) </strong></h4></div>";
    } 

    elseif ($_FILES['page1']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    }

    elseif ($_FILES['page2']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    }

    elseif ($_FILES['page3']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    }

    

     else {


          // Hizi apa zinaenda kuhifadhiwa katika folder 
        if($file1 AND $file2 AND $file3 AND $file4 AND $file5){

          move_uploaded_file($file1, $destination1);
          move_uploaded_file($file2, $destination2);
          move_uploaded_file($file3, $destination3);
          move_uploaded_file($file4, $destination4);
          move_uploaded_file($file5, $destination5);

                      
$sql = mysqli_query($conn,"INSERT INTO wajane(regNo,name,dob,gender,mkoa,wilaya,shehia,address,sim,idNo,page1,m_name,m_gender,uhusiano,m_id,m_sim,page2,s_name,s_mkoa,s_wilaya,s_shehia,anapoishi,page3,image,kiwango,m_image)
     VALUES('$regNo','$name','$dob','$gender','$mkoa','$wilaya','$shehia','$address','$sim','$idNo','$page1','$m_name','$m_gender','$uhusiano','$m_id','$m_sim','$page2','$s_name','$s_mkoa','$s_wilaya','$s_shehia','$anapoishi','$page3','$image','$kiwango','$m_image')");



 if($sql){
                 $mgs=1;
                }
             else{
                  echo"<div class= 'alert alert-success'><center><strong><h4>TAARIFA ULIZO ZIINGIZA ZIMESHAHIFADHIWA</strong></h4></div>";
                }

            ?>
<?php


    }




}
//errer

      

} 

?>


</div>

<div class="tile">



  <?php if($mgs){

  ?>

  <div class="alert alert-success">
    <center><strong><h3>UMEFANIKIWA!</strong> KUINGIZA TAARIFA;</h3>

  </div>

<?php   }?>





       <form action="widows_form.php" method="POST" enctype="multipart/form-data">
              <div class="form-row">
            

                <div class="col-md-12 mb-12">
                  <div class="picha">
                    <img id="output_image"/>
                    <input type="file" accept="image/*" onchange="preview_image(event)" name="image" required="">
                   <b><h5> Pasport Size Picture </h5></b>
                                   
                </div>
                <br> 
                <br> 
                <hr>
                <h3>Taarifa za Mwanachama </h3>
                <hr>

                </div>


                <div class="col-md-4 mb-4">
                  <label>Registration number</label>
                  <input type="text" class="form-control" placeholder="Namba usajili" name="regNo" required="">

                </div>


                <div class="col-md-4 mb-4">
                  <label>Full Name</label>
                  <input type="text" class="form-control" placeholder="Jina la Mwanachama" name="name" required="">

                </div>


                <div class="col-md-4 mb-4">
                  <label>Date of Birth</label>
                  <input type="date" class="form-control" placeholder="Tarehe ya Kuzaliwa" name="dob" required="">

                </div>


            <div class="col-md-4 mb-4">
                  <label>Select Gender</label>
                  <select class="form-control" required="" name="gender" required="">
                        <option value="">--Chagua Jinsia--</option> 
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                </select>
                </div>

              
        <div class="col-md-4 mb-4">
                  <label>Select Region</label>

          <select name="mkoa" class="form-control" onchange="show(this.value)" required>
                     <option value="">-- Chagua Mkoa  --</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM mkoa ORDER BY mkoaName DESC";
                         $result= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                      ?>
          </select>
          </div>        




                <div class="col-md-4 mb-4">
                  <label>District</label>
                  <select class="form-control" id="get_wilaya" name="wilaya" onchange="s(this.value)" required="">
                        <option value="">--Chagua Wilaya--</option> 
                  </select>
                </div>



                <div class="col-md-4 mb-4">
                  <label>Shehia</label>
                  <select class="form-control" id="get" required="" name="shehia" required="">
                        <option value="">--Chagua Shehia--</option> 
                  </select>
                </div>



                <div class="col-md-4 mb-4">
                  <label>Address</label>
                  <input type="text" class="form-control" placeholder="Jaza Sehemu unayo ishi" name="address" required="">
                </div>


                
                <div class="col-md-4 mb-4">
                  <label>Phone Number</label>
                  <input type="text" class="form-control" placeholder="Namaba ya Simu" name="sim" required="">
                </div>




                <div class="col-md-4 mb-4">
                  <label>ID Number </label>
                  <input type="text" class="form-control" placeholder="Namaba ya Kitambulisho cha Mzanzibari au Taifa" name="idNo" required="">
                </div>


                <div class="col-md-4 mb-4">
                  <label>Amouint</label>
                  <input type="number" class="form-control" placeholder="Kiasi alicho pokea" name="kiwango" required="">
                </div>

        


                

             <div class="col-md-4 mb-4">
                  <label>Upload Paper Sigin</label>
                  <input type="file" class="form-control" name="page1" required="">
                </div>


                


                <div class="col-md-9 mb-4"> 
                  <h3>Taarifa za Mzamini</h3>
                </div> 

                 <div class="col-md-10 mb-4"> 
                 <div class="picha1">
                    <img id="output"/>
                    <input type="file" accept="image/*" onchange="preview(event)" name="m_image" required="">
                   <b><h5> Weka Picha Yake  </h5></b>
                 </div> 
                 <br>
               </div>



                <div class="col-md-4 mb-4">
                  <label>Full Name</label>
                  <input type="text" class="form-control" placeholder="Jina la Mzamini" name="m_name" required="">
                </div> 


                <div class="col-md-4 mb-4">
                  <label>Select Gender</label>
                  <select class="form-control" required="" name="m_gender" required="">
                        <option value="">--Chagua Jinsia--</option> 
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                  </select>
                </div>


                <div class="col-md-4 mb-4">
                  <label>Relationship</label>
                  <select class="form-control" required="" name="uhusiano" required="">
                        <option value="">--Uhususiano--</option> 
                        <option value="Baba">Baba</option>
                        <option value="Mama">Mama</option>
                        <option value="Kaka">Kaka</option>
                        <option value="Dada">Dada</option>
                        <option value="Mjomba">Mjomba</option>
                        <option value="Shangazi">Shangazi</option>
                        <option value="Rafiki">Rafiki</option>
                  </select>
                </div>


                <div class="col-md-4 mb-4">
                  <label>ID Number</label>
                  <input type="number" class="form-control" placeholder="Namba ya Kitambulisho" name="m_id" required="">
                </div> 


                <div class="col-md-4 mb-4">
                  <label>Phone Number</label>
                  <input type="number" class="form-control" placeholder="Namba ya Simu" name="m_sim" required="">
                </div> 



                 <div class="col-md-4 mb-4">
                  <label>Upload Form Signed</label>
                  <input type="file" class="form-control" name="page2" required="">
                </div>


                <!-- Taarifa za Sheha wa Mzamini -->


                <div class="col-md-9 mb-4"> 
                  <h3>Taarifa za Sheha</h3>
                </div> 


                <div class="col-md-4 mb-4">
                  <label>Name</label>
                  <input type="text" class="form-control" placeholder="Jina La Sheha" name="s_name" required="">
                 </div> 


                 <div class="col-md-4 mb-4">
                  <label>Select Region</label>

          <select name="s_mkoa" class="form-control" onchange="sh(this.value)" required>
                     <option value="">-- Chagua Mkoa  --</option>
                      <?php 
                         include('../db/db.php'); 
                         $sheha = "SELECT * FROM mkoa ORDER BY mkoaName DESC";
                         $resul= mysqli_query($conn, $sheha);
                         while($row = mysqli_fetch_row($resul)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                      ?>
          </select>
          </div>        




                <div class="col-md-4 mb-4">
                  <label>District</label>
                  <select class="form-control" id="wila" name="s_wilaya" onchange="s2(this.value)" required="">
                        <option value="">--Chagua Wilaya--</option> 
                  </select>
                </div>



                <div class="col-md-4 mb-4">
                  <label>Shehia</label>
                  <select class="form-control" id="get2" required="" name="s_shehia" required="">
                        <option value="">--Chagua Shehia--</option> 
                  </select>
                </div>



                <div class="col-md-4 mb-4">
                  <label>Address</label>
                  <input type="text" class="form-control" placeholder="Jaza Sehemu unayo ishi" name="anapoishi" required="">
                </div>






                 <div class="col-md-4 mb-4">
                  <label>Upload Signed Form</label>
                  <input type="file" class="form-control" name="page3" required="">
                </div>


           

                

                
                                 
                 <br>
                <br>
               
                <div class="form-grop">
                    <input type="submit" name="submit" value="Send" class="btn btn-primary">
               </div>

               </form>

</div>
</div>

<br>

</div>

</main>

    <?php include('js.php') ?>



<!--
  Kuvuta Mikoa Katika Data bases
-->


<script>
function show(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_wilaya").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_wilaya").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_mikoa.php?r="+str,true);
            xmlhttp.send();
  }

}

</script>


<script>
function s(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_shehia.php?s="+str,true);
            xmlhttp.send();
  }

}

</script>








<!-- Kuvuta Shule za Madarasa -->  
  
<script>
function sh(str){
  //alert(str);
  if (str == "") {
            document.getElementById("wila").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("wila").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/wila?sh="+str,true);
            xmlhttp.send();
  }

}

</script>



<script>
function s2(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get2").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get2").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/shehia2.php?s2="+str,true);
            xmlhttp.send();
  }

}

</script>



    
  </body>
</html>