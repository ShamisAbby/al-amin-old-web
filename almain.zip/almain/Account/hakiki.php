<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


 <?php
  include('../db/db.php');

 ?>


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-eye"></i> Member Details</h1>
          <p>Corfamation</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item">Taarifa za Mwanachama</li>
          <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
        </ul>
      </div>



<div class="tile">

  <!-- Hapa Ni Kuweka vitu Unavo Vitaka -->

  <form action="single/pdf/new.php" method="POST" enctype="multipart/form-data">
              <div class="form-row">
    <div class="col-md-12 mb-12">

      <div class="col-md-6 mb-3">
          <label>Confirm Registration Number </label>
          <input type="text" class="form-control" placeholder="Thibitisha Nambari" name="regNo" required="">
     </div>

    <div class="col-md-6 mb-3">
      <input type="submit" name="submit" value="Confirm" class="btn btn-primary">
    </div>


  </div>

      </div>
       </form>
    </div>
 





 


</div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>