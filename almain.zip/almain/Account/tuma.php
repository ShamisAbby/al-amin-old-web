<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>



 <?php
 //session_start();
  include('../db/db.php');



?>



<?php
if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $regNo = $_POST['regNo'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $mkoa = $_POST['mkoa'];
    $wilaya = $_POST['wilaya'];
    $shehia = $_POST['shehia'];
    $school = $_POST['school'];
    $level = $_POST['level'];
    $class = $_POST['class'];
    $type = $_POST['type'];
    $maradhi=$_POST['maradhi'];
    $mzazi=$_POST['mzazi'];
    $sim=$_POST['sim'];
    $mlezi=$_POST['mlezi'];
    $ulemavu=$_POST['ulemavu'];

    


  $tia=mysqli_query($conn, "UPDATE wanafunzi SET regNo='$regNo', name='$name', gender='$gender',dob='$dob',mkoa='$mkoa', wilaya='$wilaya', shehia='$shehia',school='$school',level='$level',class='$class',type='$type',maradhi='$maradhi', mzazi='$mzazi',sim='$sim',mlezi='$mlezi', ulemavu='$ulemavu' WHERE id=$id");

  
  if($tia){

    echo"<div class= 'alert alert-success'><center><strong><b> Umefanikiwa Kubadili Taarifa za Mwanafunzi</strong></b></div>";
  
  }
  else{
    echo"<div class= 'alert alert-success'><center><strong><b> Hujafanikiwa Kubadili Taarifa za Mwanchama !! Tafadhali Jaribu Tena.......</strong></b></div>"; 
  }
  
}


?>

