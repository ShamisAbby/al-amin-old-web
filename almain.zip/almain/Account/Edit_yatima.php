<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


  <script type='text/javascript'>
                  function preview_image(event) 
                  {
                   var reader = new FileReader();
                   reader.onload = function()
                   {
                    var output = document.getElementById('output_image');
                    output.src = reader.result;
                   }
                   reader.readAsDataURL(event.target.files[0]);
                  }
               </script>



 <?php include('../db/db.php'); 

 $id=$_GET['id'];
 $tia=mysqli_query($conn,"SELECT * FROM wanafunzi WHERE id=$id");
  while($res=mysqli_fetch_array($tia)){
  $regNo=$res['regNo'];
  $name=$res['name'];
  $gender=$res['gender'];
  $dob=$res['dob'];
  $mkoa=$res['mkoa'];
  $wilaya=$res['wilaya'];
  $shehia=$res['shehia'];
  $school=$res['school'];
  $level=$res['level'];
  $class=$res['class'];
  $type=$res['type'];
  $maradhi=$res['maradhi'];
  $mzazi=$res['mzazi'];
  $image=$res['image'];
  $sim=$res['sim'];
  $ulemavu=$res['ulemavu'];
  $mlezi=$res['mlezi'];


  }
?>





 <?php
 //session_start();
  include('../db/db.php');



?>





 


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-eye"></i> Member Details</h1>
          <p>Taarifa za Mwanachama</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item">Taarifa za Mwanachama</li>
          <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
        </ul>
      </div>



      <?php
if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $regNo = $_POST['regNo'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $mkoa = $_POST['mkoa'];
    $wilaya = $_POST['wilaya'];
    $shehia = $_POST['shehia'];
    $school = $_POST['school'];
    $level = $_POST['level'];
    $class = $_POST['class'];
    $type = $_POST['type'];
    $maradhi=$_POST['maradhi'];
    $mzazi=$_POST['mzazi'];
    $sim=$_POST['sim'];
    $mlezi=$_POST['mlezi'];
    $ulemavu=$_POST['ulemavu'];
    $image = $_FILES['image']['name'];

     $destination1 = 'images/' . $image;

     $file1 = $_FILES['image']['tmp_name'];

    
  if($file1){
  move_uploaded_file($file1, $destination1);

  $tia=mysqli_query($conn, "UPDATE wanafunzi SET regNo='$regNo', name='$name', gender='$gender',dob='$dob',mkoa='$mkoa', wilaya='$wilaya', shehia='$shehia',school='$school',level='$level',class='$class',type='$type',maradhi='$maradhi', mzazi='$mzazi',sim='$sim',mlezi='$mlezi', ulemavu='$ulemavu',image='$image' WHERE id=$id");

  
  if($tia){

    echo"<div class= 'alert alert-success'><center><strong><b> Umefanikiwa Kubadili Taarifa za Mwanafunzi</strong></b></div>";
  
  }
  else{
    echo"<div class= 'alert alert-success'><center><strong><b> Hujafanikiwa Kubadili Taarifa za Mwanchama !! Tafadhali Jaribu Tena.......</strong></b></div>"; 
  }
  
}
}


?>





  <!-- Hapa Ni Kuweka vitu Unavo Vitaka -->

  <form action="" method="POST" enctype="multipart/form-data"> 

  <div class="container rounded bg-white mt-5">
    <div class="row">

        <div class="col-md-4 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                <div class="picha">
                <img class="prof" id="output_image"/ width="90" src="images/<?php echo $image; ?>" name="image"> 
                    <input type="file" accept="image/*" onchange="preview_image(event)" name="image" required="">
                  </div>
                                   
      <h4 class="ptext">
       <h5>Registration Number: <?php echo $regNo; ?></h5>
       <div class="no">
      <div class="col-md-8"><input type="text"  value="<?php echo $regNo?>"></div>
    </div>
     </h4>

              <div class="line"></div>

            </div>
        </div>



        <div class="col-md-8">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="d-flex flex-row align-items-center back">
  

                       
                    </div>
                    <h6 class="text-right">Member Details</h6>
                    </div>

                <hr>

        <div class="form-row">

                <div class="col-md-6 mb-4">
                  <label>Number of Member</label>
                  <input type="text" class="form-control" name="regNo" value="<?php echo $regNo; ?>">

                </div>
                
                <div class="col-md-6 mb-4">
                  <label>Full Name</label>
                  <input type="text" class="form-control" name="name" value="<?php echo $name; ?>">

                </div>

                <div class="col-md-6 mb-4">
                  <label>Gender</label>
                  <select class="form-control" required="" name="gender" required="">
                        <option value="">--Chagua_Jinsia--</option> 
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                  </select>
                </div>



                <div class="col-md-6 mb-4">
                  <label>Date of Birth</label>
                  <input type="date" class="form-control" name="dob" value="<?php echo $dob; ?>">

                </div>

               
               <div class="col-md-6 mb-4">
                  <label>Select Region</label>

          <select name="mkoa" class="form-control" onchange="show(this.value)" required>
                     <option value="">-- Chagua_Mkoa--</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM mkoa ORDER BY mkoaName DESC";
                         $result= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                      ?>
          </select>
                  


                </div>

                <div class="col-md-6 mb-4">
                  <label>District</label>
                  <select class="form-control" id="get_wilaya" required="" name="wilaya" required="">
                        <option value="">--Chagua Wilaya--</option> 
                  </select>
                </div>




                <div class="col-md-6 mb-4">
                  <label>Address</label>
                  <input type="text" class="form-control" name="shehia" value="<?php echo $shehia; ?>">

                </div>

                <div class="col-md-6 mb-4">
                  <label>Phone Number</label>
                  <input type="text" class="form-control" name="sim" value="<?php echo $sim; ?>">

                </div>



               <div class="col-md-6 mb-4">
                  <label>Select School</label>
            <select class="form-control" required="" name="school" required="">
                        <option value="">--Chagua School--</option>
                                                
                         <?php
                            include('../db/db.php');
                            $school = "SELECT * FROM school ORDER BY name";
                            $result = $conn->query($school);
                          ?>

                        <?php
                          if ($result->num_rows > 0 ) {
                             while ($row = $result->fetch_assoc()) {
                              echo '<option value='.$row['name'].'>'.$row['name'].'</option>';
                             }
                          }
                        ?> 

                  </select>
                </div>



                <div class="col-md-6 mb-4">
                  <label>Level Study</label>
                  <select name="level" class="form-control" onchange="ww(this.value)" required>
                     <option value="">-- Chagua Kiwango --</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM school_level ORDER BY level_class DESC";
                         $result= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                      ?>
          </select>
                </div>


                        



                <div class="col-md-6 mb-4">
                  <label>Select Class</label>
                  <select name="class" class="form-control" id="get_class"  required>
                      <option value="">-- Chagua Darasa--</option>
                  </select>
                </div>




                <div class="col-md-6 mb-4">
                  <label>Type of People</label>
                   <select name="type" class="form-control" required>
                     <option value="">-- Chagua Huduma --</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM huduma ORDER BY name DESC";
                         $resu= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($resu)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                       ?>
              </select>
                  
                </div>



                <div class="col-md-6 mb-4">
                  <label>Select Disease</label>
                  <select class="form-control" required="" name="maradhi" required="">
                        <option value="">--Chagua Maradhi--</option>
                        <option value="none">None</option> 
                        
                         <?php
                            include('../db/db.php');
                            $maradhi = "SELECT * FROM maradhi ORDER BY name";
                            $re = $conn->query($maradhi);
                          ?>

                        <?php
                          if ($result->num_rows > 0 ) {
                             while ($row = $re->fetch_assoc()) {
                              echo '<option value='.$row['name'].'>'.$row['name'].'</option>';
                             }
                          }
                        ?> 

                  </select>
                </div>




                <div class="col-md-6 mb-4">
                  <label>Name of the Dead Parent</label>
                  <input type="text" class="form-control" value="<?php echo $mzazi;  ?>" name="mzazi" required="">
                </div>


                


                <div class="col-md-6 mb-4">
                  <label>Guardian</label>
                   <select name="mlezi" class="form-control" required>
                     <option value="">-- Chagua Mlezi --</option>
                     <option value="None">None</option>
                      <?php 
                         include('../db/db.php'); 
                         $q = "SELECT * FROM walezi ORDER BY mlezi DESC";
                         $pw= mysqli_query($conn, $q);
                         while($row = mysqli_fetch_row($pw)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';}?>
                         
              </select>
                  
                </div>



                 


                <div class="col-md-6 mb-4">
                  <label>Disability</label>
                   <select name="ulemavu" class="form-control" required>
                     <option value="">-- Chagua Ulemavu --</option>
                     <option value="None">None</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM walemavu ORDER BY ulemavu DESC";
                         $wale= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($wale)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                       ?>
              </select>
                  
                </div>
 










       <div class="form-grop">
          <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
          <input type="submit" name="submit" value="Save" class="btn btn-primary">
       </div>
 
                
        </div>
    </div>
</div>
</form>





 


</div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>


<script>
function show(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_wilaya").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_wilaya").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_mikoa.php?r="+str,true);
            xmlhttp.send();
  }

}

</script>


<script>
function ww(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_class").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_class").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_school?q="+str,true);
            xmlhttp.send();
  }

}

</script>