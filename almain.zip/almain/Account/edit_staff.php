<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


  <script type='text/javascript'>
                  function preview_image(event) 
                  {
                   var reader = new FileReader();
                   reader.onload = function()
                   {
                    var output = document.getElementById('output_image');
                    output.src = reader.result;
                   }
                   reader.readAsDataURL(event.target.files[0]);
                  }
               </script>



 <?php include('../db/db.php'); 

 $id=$_GET['id'];
 $tia=mysqli_query($conn,"SELECT * FROM user WHERE id=$id");
  while($res=mysqli_fetch_array($tia)){
  $name=$res['name'];
  $email=$res['email'];
  $gender=$res['gender'];
  $simu=$res['simu'];
  $password=$res['password'];
  $user_type=$res['user_type'];
  $image=$res['image'];
  
  }
?>





 <?php
 //session_start();
  include('../db/db.php');



?>





 


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-eye"></i> Staff Details</h1>
          <p>Staff Infromation</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item">Staff Infromation</li>
          <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
        </ul>
      </div>



      <?php
if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $user_type = $_POST['user_type'];
    $simu = $_POST['simu'];
    $image = $_FILES['image']['name'];

     $destination1 = 'images/' . $image;

     $file1 = $_FILES['image']['tmp_name'];

    
  if($file1){
  move_uploaded_file($file1, $destination1);

  $tia=mysqli_query($conn, "UPDATE user SET name='$name', gender='$gender',email='$email',simu='$simu',user_type='$user_type',password='$password',image='$image' WHERE id=$id");

  
  if($tia){

    echo"<div class= 'alert alert-success'><center><strong><h4> Umefanikiwa Kubadili Taarifa Mfanyakazi</strong></h4></div>";
  
  }
  else{
    echo"<div class= 'alert alert-success'><center><strong><h4> Hujafanikiwa Kubadili Taarifa za Mwanchama !! Tafadhali Jaribu Tena.......</strong></h4></div>"; 
  }
  
}
}


?>





  <!-- Hapa Ni Kuweka vitu Unavo Vitaka -->

  <form action="" method="POST" enctype="multipart/form-data"> 

  <div class="container rounded bg-white mt-5">
    <div class="row">

        <div class="col-md-4 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                <div class="picha">
                <img class="prof" id="output_image"/ width="90" src="images/<?php echo $image; ?>" name="image"> 
                    <input type="file" accept="image/*" onchange="preview_image(event)" name="image" required="">
                  </div>
                                   
      <h4 class="ptext">
       <h5>Name: <?php echo $name; ?></h5>
       <div class="no">
      <div class="col-md-8"><input type="text"  value="<?php echo $name?>"></div>
    </div>
     </h4>

              <div class="line"></div>

            </div>
        </div>



        <div class="col-md-8">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="d-flex flex-row align-items-center back">
  

                       
                    </div>
                    <h6 class="text-right">Member Details</h6>
                    </div>

                <hr>

        <div class="form-row">

                               
                <div class="col-md-6 mb-4">
                  <label>Full Name</label>
                  <input type="text" class="form-control" name="name" value="<?php echo $name; ?>">

                </div>


                <div class="col-md-6 mb-4">
                  <label>Gender</label>
                  <select class="form-control" required="" name="gender" required="">
                        <option value="">--Chagua_Jinsia--</option> 
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                  </select>
                </div>



                <div class="col-md-6 mb-4">
                  <label>Email</label>
                  <input type="text" class="form-control" name="email" value="<?php echo $email; ?>">

                </div>


                <div class="col-md-6 mb-4">
                  <label>Password</label>
                  <input type="text" class="form-control" name="password" value="<?php echo $password; ?>">

                </div>




                <div class="col-md-6 mb-4">
                  <label>Select User Type <b style="color: red">*</b></label>
                  <select class="form-control" required="" name="user_type" required="">
                        <option value="disabled"><?php echo $user_type; ?></option> 
                        <option value="Acountant">Account</option>
                        <option value="Reception">Reception</option>
                        <option value="Miradi">Miradi</option>
                        <option value="Administratior">Admin</option>
                </select>
                </div>



                
                
                 <div class="col-md-6 mb-4">
                  <label>Phone Number</label>
                  <input type="text" class="form-control" name="simu" value="<?php echo $simu; ?>">

                </div>

               


       <div class="form-grop">
          <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
          <input type="submit" name="submit" value="Save" class="btn btn-primary">
       </div>
 
                
        </div>
    </div>
</div>
</form>





 


</div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>


<script>
function show(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_wilaya").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_wilaya").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_mikoa.php?r="+str,true);
            xmlhttp.send();
  }

}

</script>


<script>
function ww(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_class").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_class").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_school?q="+str,true);
            xmlhttp.send();
  }

}

</script>