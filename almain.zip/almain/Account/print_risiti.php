<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


<?php      
require("single/pdf/fpdf.php");
     $pdf = new FPDF();
    include('../db/db.php');

 ?>
 


<?php
$pdf->SetTitle("Al-Amin Relief Foundation");
 if(isset($_POST["generate_pdf"]))  
 {  
   $id=$_GET['id'];
     $sql = mysqli_query($conn, "SELECT * FROM mkopo WHERE id =$id");
          
        $row=mysqli_fetch_assoc($sql);


     $pdf->AddPage();
              $pdf->SetFont("Times","",11);

             $pdf->Cell(50,10,"Al-Amin Relief Foundation",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(20,10,"P.O.BOx:",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(77,10,"Tel: +255 778 753  384 / +255 776 529 210",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(65,10,"E-Mail:info@alaminfoundation.or.tz",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(54,10,"Website:laminfoundation.or.tz",60,0,"C");
             $pdf->Ln(7);
             $pdf->Line(12,45,200,45);

             $pdf->Image("almin.jpeg",170,17,30);
             
                
                   
             $pdf->SetFont("Times","B",18);
                                   $pdf->SetTextColor(153,0,153);
             $pdf->Cell(185,10,"WIDOWS INFORMATION PAYMENT",60,0,"C");

              
             $pdf->Ln(30); 
             $pdf->SetTextColor(32,32,32); 
                          
            
              //$pdf->Image('images/'.$row['image'],167,65,30);
              $pdf->Ln(10);
              $pdf->SetFont("Times","B",14);
              $pdf->SetTextColor(0,0,255);
              $pdf->Cell(40,10,'Personal Information');
              $pdf->Ln(8);
              $pdf->SetTextColor(32,32,32);
              $pdf->SetFont("Times","B",12);
              $pdf->Cell(90,10,"Regstration Number :",1,0);
              $pdf->Cell(90,10,$row['regNo'],1,1);

              
              $pdf->SetTextColor(32,32,32);  
              $pdf->Cell(90,10,"Full Name :",1,0);
              $pdf->Cell(90,10,$row['name'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Gender:",1,0);
              $pdf->Cell(90,10,$row['gender'],1,1);
              $pdf->SetTextColor(32,32,32);


              $pdf->SetTextColor(32,32,32);  
              $pdf->Cell(90,10,"Address :",1,0);
              $pdf->Cell(90,10,$row['address'],1,1);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(90,10,"Phone Number:",1,0);
              $pdf->Cell(90,10,$row['sim'],1,1);
              $pdf->SetTextColor(32,32,32);
              


              




              $pdf->Ln(20);
              $pdf->SetFont("Times","B",18);
              $pdf->SetTextColor(153,0,153);
 $pdf->Cell(185,10,"INFROMATION DETAILS",60,0,"C");

$pdf->Ln(25);
$pdf->SetTextColor(153,0,0);
$pdf->SetFont("Times","B",12);
$pdf->Cell(50,10,'Amount of Loan:');
$pdf->SetTextColor(0,0,255);
$pdf->Cell(50,10,$row['amount']);
$pdf->Ln(8);
$pdf->SetTextColor(153,0,0);
$pdf->Cell(50,10,'Pay Amount');
$pdf->SetTextColor(0,0,255);
$pdf->Cell(50,10,$row['pay_amount']);
$pdf->Ln(8);
$pdf->SetTextColor(153,0,0);
$pdf->Cell(50,10,'Date of Payment');
$pdf->SetTextColor(0,0,255);
$pdf->Cell(50,10,$row['pay_date']);



$pdf->Ln(8);







             
            

 
 $pdf->output();
  }

 
?>





 <?php
  include('../db/db.php');



$id=$_GET['id'];
$result=mysqli_query($conn,"SELECT * FROM mkopo WHERE id=$id");
while($res=mysqli_fetch_array($result)){
  $regNo=$res['regNo'];
  $name=$res['name'];
  $gender=$res['gender'];
  $address=$res['address'];
  $sim=$res['sim'];
  $amount=$res['amount'];
  $pay_amount=$res['pay_amount'];
  $pay_date=$res['pay_date'];
  
    }
?>
 


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      
<div class="container">
    <div class="main-body">
    
          <!-- Breadcrumb -->
          <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
            <div class="col-md-12">
                     <form method="post">  
                      
                          <input type="submit" name="generate_pdf" class="btn btn-success" value="Download"> 


                     </form> 
                     </div>
            </ol>
          </nav>
          <!-- /Breadcrumb -->
    
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                     <img class="prof" src="sampo.jpg" name="image" width="20">

                     

                    <div class="mt-3">
                      <h4><h5>Reg.Number: <?php echo $regNo; ?></h5></h4>
                                          </div>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name: </h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $name?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Gender</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $gender ?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Address </h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $address ?>
                    </div>
                  </div>

                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Phone Number</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $sim ?>
                    </div>
                  </div>

                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Amount loan</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $amount ?>
                    </div>
                  </div>


                  <hr>


                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Pay Amount</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $pay_amount ?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Date</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $pay_date ?>
                    </div>
                  </div>
                  <hr>


                  
                  

                  

                  

                

                </div>
              </div>


              

            </div>
          </div>

        </div>
    </div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>

