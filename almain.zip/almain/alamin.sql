-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2022 at 04:53 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alamin`
--

-- --------------------------------------------------------

--
-- Table structure for table `huduma`
--

CREATE TABLE `huduma` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `huduma`
--

INSERT INTO `huduma` (`id`, `name`) VALUES
(1, 'Orphan'),
(2, 'widows');

-- --------------------------------------------------------

--
-- Table structure for table `madarasa`
--

CREATE TABLE `madarasa` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `classId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `madarasa`
--

INSERT INTO `madarasa` (`id`, `name`, `classId`) VALUES
(1, 'KG 1', 1),
(2, 'KG 2', 1),
(3, 'STD 1', 2),
(4, 'STD 2', 2),
(5, 'STD 3', 2),
(6, 'STD 4', 2),
(7, 'STD 5', 2),
(8, 'STD 6', 2),
(9, 'STD 7', 2),
(10, 'Form One', 3),
(11, 'Form Two', 3),
(12, 'Form Three', 3),
(13, 'Form Four', 3);

-- --------------------------------------------------------

--
-- Table structure for table `maradhi`
--

CREATE TABLE `maradhi` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maradhi`
--

INSERT INTO `maradhi` (`id`, `name`) VALUES
(1, 'Anaugua'),
(2, 'Goti'),
(3, 'Keniya'),
(4, 'Kicwa'),
(5, 'Kifua'),
(6, 'Kitovu'),
(7, 'Macho'),
(8, 'Maradhi ya Ngozi'),
(9, 'Miguu na Macho'),
(10, 'Mifupa'),
(11, 'Mlemavu'),
(12, 'Pumu'),
(13, 'Sikio'),
(14, 'Tumbo'),
(15, 'Upungufu wa Akili');

-- --------------------------------------------------------

--
-- Table structure for table `mkoa`
--

CREATE TABLE `mkoa` (
  `id` int(11) NOT NULL,
  `mkoaName` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mkoa`
--

INSERT INTO `mkoa` (`id`, `mkoaName`) VALUES
(1, 'Kaskazini Unguja'),
(2, 'Kaskazini Pemba'),
(3, 'Kusini Unguja'),
(4, 'Kusini Pemba'),
(5, 'Mjini Magharibi ');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`id`, `name`) VALUES
(1, 'ABEID AMAAN KARUME'),
(2, 'ABOUD JUMBE MWINYI'),
(3, 'AL-FALAH MUSLIM'),
(4, 'AL-HARAMYN INTERGRATED SCHOOL'),
(5, 'AL-IHSAN GIRLS'),
(6, 'AL-ISWLAAH'),
(7, ' AL-MARFAA ISLAMIC SCHOOL'),
(8, 'AL-MUBARAK'),
(9, 'AL-QUWIYYI'),
(10, 'AL-RIYAMI ACADEMY'),
(11, 'ALI HASSAN MWINYI SECONDARY'),
(12, 'ALI KHAMIS CAMP'),
(13, 'AMAAN ABEID KARUME'),
(14, 'AMBASHA ISLAMIC HIGH SCHOOL'),
(15, 'AMINI ISLAMIC'),
(16, 'ASFAT ISLAMIC SCHOOL'),
(17, 'ASSALAM SCHOOL KONDE'),
(18, 'BALTON ACADEMY'),
(19, 'BAMBI'),
(20, 'BANDAMAJI'),
(21, 'BEIT-EL-RAS'),
(22, 'BEN-BELLA'),
(23, 'BIRIKAU SEKONDARI'),
(24, 'BRIGHT FUTURE ACADEMY'),
(25, 'BRILLIANT ACADEMY'),
(26, 'BUBUBU'),
(27, 'BUMBWINI'),
(28, 'BWAGAMOYO'),
(29, 'BWEFUM'),
(30, 'BWEJUU');

-- --------------------------------------------------------

--
-- Table structure for table `school_level`
--

CREATE TABLE `school_level` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `sId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `school_level`
--

INSERT INTO `school_level` (`id`, `name`, `sId`) VALUES
(1, 'Nussary School', 1),
(2, 'Primary School', 1),
(3, 'Secondary School', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shehia`
--

CREATE TABLE `shehia` (
  `id` int(11) NOT NULL,
  `shehiaName` varchar(250) NOT NULL,
  `sId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shehia`
--

INSERT INTO `shehia` (`id`, `shehiaName`, `sId`) VALUES
(1, 'Konde', 1),
(2, 'Mgogoni', 1),
(3, 'Bopwe', 2),
(4, 'Jadida', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `status` enum('Account','Mapokezi','Miradi','Admin') NOT NULL,
  `simu` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `date_register` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `status`, `simu`, `image`, `date_register`) VALUES
(1, 'Yahya Mwinyi Ally', 'yahya@gmail.com', '1234', 'Admin', '0778141964', 'hhh.jpg', '2022-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `wanafunzi`
--

CREATE TABLE `wanafunzi` (
  `id` int(11) NOT NULL,
  `regNo` varchar(100) NOT NULL,
  `name` varchar(250) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(20) NOT NULL,
  `mkoa` varchar(20) NOT NULL,
  `wilaya` varchar(20) NOT NULL,
  `shehia` varchar(20) NOT NULL,
  `sim` varchar(250) NOT NULL,
  `school` varchar(200) NOT NULL DEFAULT '0',
  `level` varchar(30) NOT NULL DEFAULT '0',
  `class` varchar(30) NOT NULL,
  `type` varchar(250) NOT NULL,
  `chetkifo` varchar(250) NOT NULL DEFAULT '0',
  `chetdob` varchar(250) NOT NULL DEFAULT '0',
  `maradhi` varchar(100) NOT NULL,
  `mzazi` varchar(200) NOT NULL,
  `dateReg` date NOT NULL DEFAULT current_timestamp(),
  `year` year(4) NOT NULL DEFAULT current_timestamp(),
  `image` varchar(250) NOT NULL,
  `comment` text NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wanafunzi`
--

INSERT INTO `wanafunzi` (`id`, `regNo`, `name`, `dob`, `gender`, `mkoa`, `wilaya`, `shehia`, `sim`, `school`, `level`, `class`, `type`, `chetkifo`, `chetdob`, `maradhi`, `mzazi`, `dateReg`, `year`, `image`, `comment`, `size`) VALUES
(152, 'Ali Juma', 'jhfkdjfdj', '2022-04-07', 'Male', '2', '1', '1', '099', '1', '1', '2', '1', '444.pdf', 'applicationPackage.pdf', '14', 'jekj', '2022-04-29', 2022, 'ddd.jpg', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wilaya`
--

CREATE TABLE `wilaya` (
  `id` int(11) NOT NULL,
  `wilaya` varchar(250) NOT NULL,
  `wId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wilaya`
--

INSERT INTO `wilaya` (`id`, `wilaya`, `wId`) VALUES
(1, 'Micheweni', 2),
(2, 'Wete', 2),
(3, 'Magharibi', 5),
(4, 'Mjini Magharibi', 5),
(5, 'Kaskazini ‘A’', 1),
(6, 'Kaskazini ‘B’', 1),
(7, 'Kati Unguja', 3),
(8, 'Kusini Unguja', 3),
(9, 'Chake Chake', 4),
(10, 'Mkoan', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `huduma`
--
ALTER TABLE `huduma`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `madarasa`
--
ALTER TABLE `madarasa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maradhi`
--
ALTER TABLE `maradhi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mkoa`
--
ALTER TABLE `mkoa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_level`
--
ALTER TABLE `school_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shehia`
--
ALTER TABLE `shehia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `simu` (`simu`);

--
-- Indexes for table `wanafunzi`
--
ALTER TABLE `wanafunzi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `regNo` (`regNo`),
  ADD KEY `regNo_2` (`regNo`);

--
-- Indexes for table `wilaya`
--
ALTER TABLE `wilaya`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `huduma`
--
ALTER TABLE `huduma`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `madarasa`
--
ALTER TABLE `madarasa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `maradhi`
--
ALTER TABLE `maradhi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `mkoa`
--
ALTER TABLE `mkoa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `school_level`
--
ALTER TABLE `school_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shehia`
--
ALTER TABLE `shehia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wanafunzi`
--
ALTER TABLE `wanafunzi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `wilaya`
--
ALTER TABLE `wilaya`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
