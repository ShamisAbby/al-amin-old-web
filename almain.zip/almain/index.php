<!DOCTYPE html>
<html lang="en">
<head>
<link href="admin/img/logo/msuka.jpg" rel="icon">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>alamin</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/style2.css">
<script src="css/min.js"></script>
<script src="css/umd.js"></script>
<script src="css/bootstrap.js"></script> 
<style>
body {
	color: #fff;
	background: #CFECEC;
	font-family: 'Roboto', sans-serif;
}

.top{
  margin-top: 80px;
  
}

.form-control {
	font-size: 16px;
	background: #f2f2f2;
	box-shadow: none !important;
	border-color: transparent;
}
.form-control:focus {
	border-color: #d3d3d3;
}
.form-control, .btn {        
	border-radius: 5px;
}
.login-form {
	width: 380px;
	margin: 0 auto;
	margin-top: 50px;
	font-size: 15px;
}
.login-form h2 {		
	margin: 0;
	padding: 60px 0;
	font-size: 34px;
}
.login-form .avatar {
	margin: 0 auto 30px;
	width: 140px;
	height: 70px;
	border-radius: 50%;
	z-index: 9;
	padding: 10px;
	
}


.login-form .avatar img {
	width: 100%;
}
.login-form form {
	color: #7a7a7a;
	border-radius: 5px;
	margin-bottom: 15px;
	background: #fff;
	box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	padding: 30px;		
}	
.login-form .btn, .login-form .btn:active {
	font-weight: bold;
	background: #728FCE !important;
	border: none;
	margin-bottom: 20px;
}
.login-form .btn:hover, .login-form .btn:focus {
	background: #045F5F !important;
}
.login-form a {
	color: #ef3b3a;
}	
.login-form form a {
	color: blue;
}
.login-form a:hover, .login-form form a:hover {
	text-decoration: underline;
}
.hint-text {
	color: black;
	text-align: center;
	padding: 50px;
}
.form-footer {
	padding-bottom: 15px;
	text-align: center;
}

.form-group{
	padding-bottom: 10px; 
}

.form-control{
	height: 50px;
	
}




@media screen and (max-width: 440px) {
  .login-form{
    width: 95%;
    margin-top: 0;

  }
  
}


</style>
</head>
<body>
<div class="top">	
<div class="login-form">
	   <form action="chack.php" method="POST">
	   	<h4 class="text-center">Al-Amin Relief Foundation</h4>
	   	<hr>
		<div class="avatar">
			<img src="almin.jpeg" alt="Avatar">

		</div> 


        <div class="form-group">
        	<input type="email" class="form-control input-lg" name="email" placeholder="Username" required="required">
        </div>
		<div class="form-group">
            <input type="password" class="form-control input-lg" name="password" placeholder="Password" required="required" autocomplete="off">
        </div>        
        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-lg btn-block login-btn" name="login">Login</button>
        </div>
 
				
    </form>
    </div>
 </div>
</body>
</html>