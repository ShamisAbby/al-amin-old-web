<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


  <script type='text/javascript'>
                  function preview_image(event) 
                  {
                   var reader = new FileReader();
                   reader.onload = function()
                   {
                    var output = document.getElementById('output_image');
                    output.src = reader.result;
                   }
                   reader.readAsDataURL(event.target.files[0]);
                  }
               </script>




<?php
  include('../db/db.php');
 
?>


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i> Registertion Form</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item"><a href="#">Form Components</a></li>
        </ul>
      </div>




      <div class="col-lg-12">

            <div class="panel panel-default">

<?php
$mgs=0;

if (isset($_POST['submit'])) { // if save button on the form is clicked
    // name of the uploaded file
    $image = $_FILES['image']['name'];
    $chetkifo = $_FILES['chetkifo']['name'];
    $chetdob = $_FILES['chetdob']['name'];

       $regNo = $_POST['regNo'];
       $name = $_POST['name'];
       $dob = $_POST['dob'];
       $gender = $_POST['gender'];
       $mkoa = $_POST['mkoa'];
       $wilaya = $_POST['wilaya'];
       $shehia =  $_POST['shehia'];
       $sim = $_POST['sim'];
       $school =  $_POST['school'];
       $level =  $_POST['level'];
       $class =  $_POST['class'];
       $type =  $_POST['type'];
       $maradhi =  $_POST['maradhi'];
       $mzazi = $_POST['mzazi'];
       $mlezi =  $_POST['mlezi'];
       $ulemavu = $_POST['ulemavu'];
       $hali = $_POST['hali'];     

    // destination of the file on the server
    $destination1 = 'images/' . $image;
    $destination2 = 'images/' . $chetkifo;
    $destination3 = 'images/' . $chetdob;


    // get the file extension
    $extension = pathinfo($image, PATHINFO_EXTENSION);
    $extension = pathinfo($chetkifo, PATHINFO_EXTENSION);
    $extension = pathinfo($chetdob, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file1 = $_FILES['image']['tmp_name'];
    $file2 = $_FILES['chetkifo']['tmp_name'];
    $file3 = $_FILES['chetdob']['tmp_name'];
    $size = $_FILES['image']['size'];
    $size = $_FILES['chetkifo']['size'];
    $size = $_FILES['chetdob']['size'];

    
   if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
       // echo "You file extension must be .zip, .pdf or .docx";

        echo"<div class= 'alert alert-success'><center><strong><h4>Your file extension must be (zip) , (pdf) OR (docx) </strong></h4></div>";
    } 

    elseif ($_FILES['chetkifo']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    }

    elseif ($_FILES['chetdob']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    }


     else {


          // Hizi apa zinaenda kuhifadhiwa katika folder 
        if($file1 AND $file2 AND $file3){

          move_uploaded_file($file1, $destination1);
          move_uploaded_file($file2, $destination2);
          move_uploaded_file($file3, $destination3);

                      
            $sql = mysqli_query($conn,"INSERT INTO wanafunzi(regNo,name,dob,gender,mkoa,wilaya,shehia,sim,school,level,class,type,maradhi,mzazi,mlezi,ulemavu, image,chetkifo,chetdob,hali)
     VALUES('$regNo','$name','$dob','$gender','$mkoa','$wilaya','$shehia','$sim','$school','$level','$class','$type','$maradhi','$mzazi','$mlezi','$ulemavu','$image','$chetkifo','$chetdob','$hali')");



 if($sql){
                 $mgs=1;
                }
             else{
                  echo"<div class= 'alert alert-success'><center><strong><h4>TAARIFA ULIZO ZIINGIZA ZIMESHAHIFADHIWA</strong></h4></div>";
                }

            ?>
<?php


    }




}
//errer

      

} 

?>


</div>

<div class="tile">



  <?php if($mgs){

  ?>

  <div class="alert alert-success">
    <center><strong><h3>UMEFANIKIWA!</strong> KUINGIZA TAARIFA;</h3>

  </div>

<?php   }?>





       <form action="reggroup.php" method="POST" enctype="multipart/form-data">
              <div class="form-row">
            

                <div class="col-md-12 mb-12">
                  <div class="picha">
                    <img id="output_image"/>
                    <input type="file" accept="image/*" onchange="preview_image(event)" name="image" required="">
                   <b><h5> Pasport Size Picture <b style="color: red;font-size:18">*</b> </h5></b>
                                   
                </div>
                <br> 
                <br> 
                <hr>

                </div>

                <div class="col-md-3 mb-3">
                  <label>Registration number <b style="color: red;font-size:18">*</b></label>
                  <input type="text" class="form-control" placeholder="Namba usajili" name="regNo" required="">

                </div>


                <div class="col-md-3 mb-3">
                  <label>Full Name <b style="color: red;font-size:18">*</b></label>
                  <input type="text" class="form-control" placeholder="Jina la Mwanachama" name="name" required="">

                </div>


                <div class="col-md-3 mb-3">
                  <label>Date of Birth</label>
                  <input type="date" class="form-control" placeholder="Tarehe ya Kuzaliwa" name="dob">

                </div>


            <div class="col-md-3 mb-3">
                  <label>Select Gender <b style="color: red;font-size:18">*</b></label>
                  <select class="form-control" required="" name="gender" required="">
                        <option value="">--Chagua Jinsia--</option> 
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        
                  
                  </select>
                </div>

              
                <div class="col-md-3 mb-3">
                  <label>Select Region <b style="color: red;font-size:18">*</b></label>

          <select name="mkoa" class="form-control" onchange="show(this.value)" required>
                     <option value="">-- Chagua Mkoa  --</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM mkoa ORDER BY mkoaName DESC";
                         $result= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                      ?>
          </select>
                  


                </div>

                <div class="col-md-3 mb-3">
                  <label>District <b style="color: red;font-size:18">*</b></label>
                  <select class="form-control" id="get_wilaya" required="" name="wilaya" required="">
                        <option value="">--Chagua Wilaya--</option> 
                  </select>
                </div>


                <div class="col-md-3 mb-3">
                  <label>Address <b style="color: red;font-size:18">*</b></label>
                  <input type="text" class="form-control" placeholder="Jaza Sehemu unayo ishi" name="shehia" required="">
                </div>


                
                <div class="col-md-3 mb-3">
                  <label>Phone Number <b style="color: red;font-size:18">*</b></label>
                  <input type="text" class="form-control" placeholder="Namaba ya Simu" name="sim" required="">
                </div>

               


               <!-- Scholl Get -->

              
                        <?php
                            include('../db/db.php');
                            $school = "SELECT * FROM school ORDER BY name";
                            $result = $conn->query($school);
                          ?>

               
               <div class="col-md-3 mb-3">
                  <label>Select School</label>
            <select class="form-control" name="school">
                        <option value="">--Chagua School--</option>
                                                
                         <?php
                            include('../db/db.php');
                            $school = "SELECT * FROM school ORDER BY name";
                            $result = $conn->query($school);
                          ?>

                        <?php
                          if ($result->num_rows > 0 ) {
                             while ($row = $result->fetch_assoc()) {
                              echo '<option value='.$row['name'].'>'.$row['name'].'</option>';
                             }
                          }
                        ?> 

                  </select>
                </div>


               <div class="col-md-3 mb-3">
                  <label>Level Study</label>
                  <select name="level" class="form-control" onchange="ww(this.value)">
                     <option value="">-- Chagua Kiwango --</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM school_level ORDER BY level_class DESC";
                         $result= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                      ?>
          </select>
                </div>


                        



                <div class="col-md-3 mb-3">
                  <label>Select Class</label>
                  <select name="class" class="form-control" id="get_class">
                      <option value="">-- Chagua Darasa--</option>
                  </select>
                </div>



                

               <div class="col-md-3 mb-3">
                  <label>Type of People <b style="color: red;font-size:18">*</b></label>
                   <select name="type" class="form-control" required>
                     <option value="">-- Chagua Huduma --</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM huduma ORDER BY name DESC";
                         $result= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                       ?>
              </select>
                  
                </div>






                 <div class="col-md-3 mb-3">
                  <label>Death certificate/ Barua ya sheha  <b style="color: red;font-size:18">*</b></label>
                  <input type="file" class="form-control" name="chetkifo">
                </div>


                 <div class="col-md-3 mb-3">
                  <label>Barth certificate / Barua ya sheha <b style="color: red;font-size:18">*</b></label>
                  <input type="file" class="form-control" name="chetdob">
                </div>


                


                 <div class="col-md-3 mb-3">
                  <label>Select Disease</label>
                   <select name="maradhi" class="form-control">
                     <option value="">-- Chagua Maradhi --</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM maradhi ORDER BY name DESC";
                         $result= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                       ?>
              </select>
                  
                </div>




                <div class="col-md-3 mb-3">
                  <label>Name of the Dead Parent <b style="color: red;font-size:18">*</b></label>
                  <input type="text" class="form-control" placeholder="Jina la Mzazi aliye kufa" name="mzazi" required="">

                </div>


               

                <div class="col-md-6 mb-4">
                  <label>Disability</label>
                   <select name="ulemavu" class="form-control">
                     <option value="">-- Chagua Ulemavu --</option>
                     <option value="None">None</option>
                      <?php 
                         include('../db/db.php'); 
                         $query = "SELECT * FROM walemavu ORDER BY ulemavu DESC";
                         $result= mysqli_query($conn, $query);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                       ?>
              </select>
                  
                </div>


                <div class="col-md-3 mb-3">
                  <label>Guardian <b style="color: red;font-size:18">*</b></label>
                   <select name="mlezi" class="form-control" required>
                     <option value="">-- Chagua Mlezi --</option>
                     <option value="None">None</option>
                      <?php 
                         include('../db/db.php'); 
                         $q = "SELECT * FROM walezi ORDER BY mlezi DESC";
                         $result= mysqli_query($conn, $q);
                         while($row = mysqli_fetch_row($result)){
                            echo '<option value="'.$row[1].'">'.$row[1].'</option>';
                         }
                       ?>
              </select>
                  
                </div>



                <div class="col-md-3 mb-3">
                  <label>Select Status <b style="color: red;font-size:18">*</b></label>
                  <select class="form-control" required="" name="hali" required="">
                        <option value="">--Status--</option> 
                        <option value="Complete">Complete</option>
                        <option value="Not Complete">Not Complete</option>
                        
                  
                  </select>
                </div>



                

                
               
                 
                 <br>
                <br>
               
                <div class="form-grop">
                    <input type="submit" name="submit" value="Send" class="btn btn-primary">
               </div>
                </form>

</div>
</div>

<br>

</div>
</main>

    <?php include('js.php') ?>



<!--
  Kuvuta Mikoa Katika Data bases
-->


<script>
function show(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_wilaya").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_wilaya").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_mikoa.php?r="+str,true);
            xmlhttp.send();
  }

}

</script>








<!-- Kuvuta Shule za Madarasa -->  
  
<script>
function ww(str){
  //alert(str);
  if (str == "") {
            document.getElementById("get_class").innerHTML = "";
            return;
    } else {
      if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
      xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("get_class").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET","get/get_school?q="+str,true);
            xmlhttp.send();
  }

}

</script>



    
  </body>
</html>