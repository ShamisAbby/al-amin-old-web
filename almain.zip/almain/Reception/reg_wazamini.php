<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>



<?php
  include('../db/db.php');
 
?>


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i> Registertion Form</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item"><a href="#">Form Components</a></li>
        </ul>
      </div>




      <div class="col-lg-12">

            <div class="panel panel-default">

<?php
$mgs=0;

if (isset($_POST['submit'])) { // if save button on the form is clicked
    
       $reg = $_POST['reg'];
       $name = $_POST['name'];
       $gender = $_POST['gender'];
       $address =  $_POST['address'];
       $email =  $_POST['email'];
       $sim = $_POST['sim'];
               

$sql = mysqli_query($conn,"INSERT INTO reg_wazamin(reg,name,gender,address,email,sim)
     VALUES('$reg' , '$name', '$gender', '$address', '$email', '$sim')");



 if($sql){
                 $mgs=1;
                }
             else{
                  echo"<div class= 'alert alert-success'><center><strong><h4>TAARIFA ULIZO ZIINGIZA ZIMESHAHIFADHIWA</strong></h4></div>";
                }

            ?>
<?php


    }




?>


</div>

<div class="tile">



  <?php if($mgs){

  ?>

  <div class="alert alert-success">
    <center><strong><h3>UMEFANIKIWA!</strong> KUINGIZA TAARIFA;</h3>

  </div>

<?php   }?>





       <form action="reg_wazamini.php" method="POST" enctype="multipart/form-data">
              <div class="form-row">
              


              <div class="col-md-6 mb-4">
                  <label>Ragistartion Number <b style="color: red">*</b></label>
                  <input type="text" class="form-control" placeholder="Namba ya Mzamini" name="reg" required="">

                </div>
              

                <div class="col-md-6 mb-4">
                  <label>Full Name <b style="color: red">*</b></label>
                  <input type="text" class="form-control" placeholder="Jina la Mzamini" name="name" required="">

                </div>


            <div class="col-md-6 mb-4">
                  <label>Select Gender <b style="color: red">*</b></label>
                  <select class="form-control" required="" name="gender" required="">
                        <option value="">--Chagua Jinsia--</option> 
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                </select>
                </div>



                <div class="col-md-6 mb-4">
                  <label>Address <b style="color: red">*</b></label>
                  <input type="text" class="form-control" placeholder="Jina la Mzamini" name="address" required="">

                </div>

                <div class="col-md-6 mb-4">
                  <label>Email <b style="color: red">*</b></label>
                  <input type="email" class="form-control" placeholder="Barua Pepe" name="email" required="">

                </div>


                <div class="col-md-6 mb-4">
                  <label>Phone Number <b style="color: red">*</b></label>
                  <input type="text" class="form-control" placeholder="Nambari ya Simu" name="sim" required="">

                </div>


          
                
                                 
                 <br>
                <br>
               
                <div class="form-grop">
                    <input type="submit" name="submit" value="Send" class="btn btn-primary">
               </div>

               </form>

</div>
</div>

<br>

</div>

</main>

    <?php include('js.php') ?>



<!--
  Kuvuta Mikoa Katika Data bases
-->


  

    
  </body>
</html>