 <?php 
 session_start(); 
include 'db/db.php';
if (isset($_POST['login'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];
 

   // Admin
   $sql = mysqli_query($conn, "SELECT * FROM user WHERE  email = '$email' and password = '$password' and user_type='Reception' ");
  if (mysqli_num_rows($sql) > 0) {
    $data = mysqli_fetch_assoc($sql);
    $_SESSION['email'] = $data['email'];
    $_SESSION['id'] = $data['id'];
    $_SESSION['user_type'] = $data['user_type'];
    $_SESSION['name'] = $data['name'];
    header("location:Reception/dashboard.php");
}

  // mapokezi
   $sql = mysqli_query($conn, "SELECT * FROM user WHERE  email = '$email' and password = '$password' and user_type='Administratior'");
  if (mysqli_num_rows($sql) > 0) {
    $data = mysqli_fetch_assoc($sql);
    $_SESSION['email'] = $data['email'];
    $_SESSION['id'] = $data['id'];
    $_SESSION['user_type'] = $data['user_type'];
    $_SESSION['name'] = $data['name'];
    header("location:Admin/dashboard.php");
}


  // Accountant
   $sql = mysqli_query($conn, "SELECT * FROM user WHERE email = '$email' and password = '$password' and user_type='Account'");
    
  if (mysqli_num_rows($sql) > 0) {
    $data = mysqli_fetch_assoc($sql);
    $_SESSION['email'] = $data['email'];
    $_SESSION['id'] = $data['id'];
    $_SESSION['user_type'] = $data['user_type'];
    $_SESSION['name'] = $data['name'];
    header("location:Account/dashboard.php");
}
  else{
 //header("Location:index.php?error=Incorect!! Username or Password");
    echo "<script>alert('Incorect!! Username or Password! Please Contact with Admin');</script> . <script>window.location = 'index.php';</script>";
 }
}
 ?>

