<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


<?php      require("single/pdf/fpdf.php");
     $pdf = new FPDF();
    include('../db/db.php');

 ?>
 


<?php
$pdf->SetTitle("Al-Amin Relief Foundation");
 if(isset($_POST["generate_pdf"]))  
 {  
   $id=$_GET['id'];
     $sql = mysqli_query($conn, "SELECT * FROM wajane WHERE id =$id");
          
        $row=mysqli_fetch_assoc($sql);


     $pdf->AddPage();
              $pdf->SetFont("Times","",11);

             $pdf->Cell(50,10,"Al-Amin Relief Foundation",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(20,10,"P.O.BOx:",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(77,10,"Tel: +255 778 753  384 / +255 776 529 210",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(65,10,"E-Mail:info@alaminfoundation.or.tz",60,0,"C");
             $pdf->Ln(7);
             $pdf->Cell(54,10,"Website:laminfoundation.or.tz",60,0,"C");
             $pdf->Ln(7);
             $pdf->Line(12,45,200,45);

             $pdf->Image("almin.jpeg",170,17,30);
             
                                      
                   
             $pdf->SetFont("Times","B",18);
                                   $pdf->SetTextColor(153,0,153);
             $pdf->Cell(185,10,"BASIC INFORMATION OF MEMBER",60,0,"C");
              
             $pdf->Ln(20); 
             $pdf->SetTextColor(128,255,0); 
             $pdf->Cell(54,-15,"Pasanal Information",100,0,"C");

             $pdf->Image("almin.jpeg",170,17,30);
             $pdf->Image('mzamini/'.$row['image'],10,63,30);


            
              $pdf->SetTextColor(32,32,32);
              $pdf->Ln(5);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(28,71,$row['regNo'],0,70,'C',0); 
              $pdf->Line(0,108,250,108);    

              $pdf->Ln(-30);
              $pdf->Cell(180,30,1,1,'L');
              $pdf->Ln(-1);


              $pdf->SetFont("Times","B",12);
              $pdf->Cell(30,10,"Full Name:",60,0,"C");
              $pdf->Ln(5);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(90,0,$row['name'],0,0,'C',0);



               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(185,0,"D.O.B:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(220,0,$row['dob'],0,0,'C',0);

               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(275,0,"Gender:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(305,0,$row['gender'],0,0,'C',0);


              $pdf->Ln(3);   

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(25,10,"Religion:",60,0,"C");
              $pdf->Ln(5);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(83,0,$row['mkoa'],0,0,'C',0);



               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(185,0,"Distrit:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(220,0,$row['wilaya'],0,0,'C',0);

               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(275,0,"Shehia:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(320,0,$row['shehia'],0,0,'C',0);




              $pdf->Ln(4);   

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(25,10,"Address:",60,0,"C");
              $pdf->Ln(5);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(83,0,$row['address'],0,0,'C',0);



               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(185,0,"Phone:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(220,0,$row['sim'],0,0,'C',0);

               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(275,0,"Zid No:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(320,0,$row['idNo'],0,0,'C',0);



             $pdf->Ln(30); 
             $pdf->SetTextColor(51,123,255); 
             $pdf->SetFont("Times","B",18);
             $pdf->Cell(54,-15,"Taarifa za Mzamini",100,0,"C");

             $pdf->Image('mzamini/'.$row['m_image'],160,165,30);
             $pdf->Ln(10);
             $pdf->SetTextColor(32,32,32);
             $pdf->SetFont("Times","",14);
             $pdf->Cell(320,75,$row['m_name'],0,0,'C',0);

             $pdf->Ln(45);
             $pdf->Cell(180,30,1,1);
             $pdf->Ln(-1);


             $pdf->Ln(2);

             $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(25,10,"Name:",60,0,"C");
              $pdf->Ln(5);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(83,0,$row['m_name'],0,0,'C',0);



               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(185,0,"Gender:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(220,0,$row['m_gender'],0,0,'C',0);

               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(275,0,"Zid",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(320,0,$row['m_id'],0,0,'C',0);



              $pdf->Ln(4);   

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(25,10,"Phone:",60,0,"C");
              $pdf->Ln(5);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(83,0,$row['m_sim'],0,0,'C',0);

               //$pdf->Ln(40);

               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(185,0,"Relationship:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(220,0,$row['uhusiano'],0,0,'C',0);

            $pdf->Ln(0);

              //$pdf->SetFont("Times","B",12);
              //$pdf->SetTextColor(32,32,32);
              //$pdf->Cell(275,0,"Zid No:",60,0,"C");
              //$pdf->Ln(0);
              //$pdf->SetTextColor(153,0,153);
              //$pdf->SetFont("Times","",12);
              //$pdf->Cell(320,0,$row['idNo'],0,0,'C',0);

              
               
             $pdf->Ln(30); 
             $pdf->SetTextColor(0,102,0); 
             $pdf->SetFont("Times","B",18);
             $pdf->Cell(54,15,"Taarifa za Sheha",100,0,"C");

              $pdf->Ln(20);
              $pdf->Cell(180,30,1,1,'L');
              $pdf->Ln(-1);


              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(30,10,"Full Name:",60,0,"C");
              $pdf->Ln(5);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(90,0,$row['s_name'],0,0,'C',0);



               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(170,0,"Religion:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(220,0,$row['s_mkoa'],0,0,'C',0);

               $pdf->Ln(0);

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(275,0,"Distrit:",60,0,"C");
              $pdf->Ln(0);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(315,0,$row['s_wilaya'],0,0,'C',0); 


              $pdf->Ln(4);   

              $pdf->SetFont("Times","B",12);
              $pdf->SetTextColor(32,32,32);
              $pdf->Cell(25,10,"Address:",60,0,"C");
              $pdf->Ln(5);
              $pdf->SetTextColor(153,0,153);
              $pdf->SetFont("Times","",12);
              $pdf->Cell(83,0,$row['anapoishi'],0,0,'C',0);


              
            


 
 $pdf->output();
  }

 
?>





 <?php
  include('../db/db.php');



$id=$_GET['id'];
$result=mysqli_query($conn,"SELECT * FROM wajane WHERE id=$id");
while($res=mysqli_fetch_array($result)){
  $regNo=$res['regNo'];
  $name=$res['name'];
  $gender=$res['gender'];
  $dob=$res['dob'];
  $mkoa=$res['mkoa'];
  $wilaya=$res['wilaya'];
  $shehia=$res['shehia'];
  $anapoishi=$res['anapoishi'];
  $idNo=$res['idNo'];
  $sim=$res['sim'];
  $m_name=$res['m_name'];
  $m_gender=$res['m_gender'];
  $uhusiano=$res['uhusiano'];
  $m_id=$res['m_id'];
  $image=$res['image'];
  $m_image=$res['m_image'];
  $m_sim=$res['m_sim'];
  $s_name=$res['s_name'];
  $s_mkoa=$res['s_mkoa'];
  $s_wilaya=$res['s_wilaya'];
  $s_shehia=$res['s_shehia'];
  //$s_anapoishi=$res['s_anapoishi'];
  $kiwango=$res['kiwango'];

  }
?>
 


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      
<div class="container">
    <div class="main-body">
    
          <!-- Breadcrumb -->
          <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
            <div class="col-md-12">
                     <form method="post">  
                      
                          <input type="submit" name="generate_pdf" class="btn btn-success" value="Download">  
                     </form> 
                     </div>
            </ol>
          </nav>
          <!-- /Breadcrumb -->
    
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img class="prof" src="mzamini/<?php echo $image; ?>" name="image" width="20">

                     

                    <div class="mt-3">
                      <h4><h5>Reg.Number: <?php echo $regNo; ?></h5></h4>
                                          </div>
                  </div>
                </div>
              </div>
              <div class="card mt-3">
                <ul class="list-group list-group-flush">
                  <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                    <h3>Pacha ya Mzamini</h3>
                    <img class="prof" src="mzamini/<?php echo $m_image; ?>" name="image" width="20">
                                      
                  </li>
                  
                  <h4 style="padding-left:30px">Full Name <?php echo $m_name  ?> </h4>
                </ul>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name: </h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $name?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Gender</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $gender ?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Date of Birth </h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $dob ?>
                    </div>
                  </div>

                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Religin</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $mkoa ?>
                    </div>
                  </div>

                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Distrit</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $wilaya ?>
                    </div>
                  </div>

                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Shehia</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $shehia ?>
                    </div>
                  </div>

                  <hr>


                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Address</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $anapoishi ?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Phone Number</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $sim ?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Id Number</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $idNo ?>
                    </div>
                  </div>
                  <hr>

                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Amont:</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $kiwango ?>
                    </div>
                  </div>
                  <hr>

                

                </div>
              </div>


              <div class="row gutters-sm">
                <div class="col-sm-6 mb-3">
                  <div class="card h-100">
                    <div class="card-body">
                      <h4 class="d-flex align-items-center mb-3">Mzamini</h4>
                      <hr>
                      <h6>Full Name: <?php echo $m_name ?></h6>
                      
                      <h6>Gender: <?php echo $gender ?></h6>
                      
                      <h6>Relationship: <?php echo $uhusiano ?></h6>
                      
                      <h6>Phone Number: <?php echo $m_sim ?> </h6>
                      
                                            
                    </div>
                  </div>
                </div>


                <div class="col-sm-6 mb-3">
                  <div class="card h-100">
                    <div class="card-body">
                      <h4 class="d-flex align-items-center mb-3">Taarifa za Sheha</h4>
                      <hr>
                      <h6>Full Name: <?php echo $s_name ?></h6>
                      
                      <h6>Religion: <?php echo $s_mkoa ?></h6>
                      
                      <h6> Distrit: <?php  echo $wilaya ?></h6>
                      
                      <h6>Shehia: <?php echo $s_shehia ?></h6>
                      
                      <h6>Address: <?php echo $anapoishi ?></h6>
                      
                    </div>
                  </div>
                </div>
              </div>



            </div>
          </div>

        </div>
    </div>
</main>

    <?php include('js.php') ?>



   
  </body>
</html>

