<aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="almin.jpeg" alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?php echo $_SESSION['name']; ?></p>
          <p class="app-sidebar__user-designation"><center style="color: red"><?php echo $_SESSION['user_type']; ?></center></p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item " href="dashboard.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label"> Dashboard</span></a>
       </li>



       <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Staff Details</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">

       <li><a class="app-menu__item" href="user.php"><i class="app-menu__icon fa fa-user-circle"></i><span class="app-menu__label"> Staff Register</span></a>
       </li>
            
             <li><a class="treeview-item" href="user_table.php"><i class="icon fa fa-address-card"></i> User Registered</a></li>
             

            </ul>
  
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-edit"></i><span class="app-menu__label">Reception Details</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="table-data-table.php"><i class="icon fa fa-circle-o"></i> Orphans Members </a></li>
            <li><a class="treeview-item" href="wajane_table.php"><i class="icon fa fa-circle-o"></i> Widows Members</a></li>
             <li><a class="treeview-item" href="user_table.php"><i class="icon fa fa-circle-o"></i> User Registered</a></li>

              <li><a class="treeview-item" href="make_sadaka.php"><i class="icon fa fa-circle-o"></i> Make Charity</a></li>
              <li><a class="treeview-item" href="remove_sadaka.php"><i class="icon fa fa-circle-o"></i> Remove Charity</a></li>
            <li><a class="treeview-item" href="downlod_charity.php"><i class="icon fa fa-circle-o"></i> Download Member</a></li>


            </ul>
        </li>



        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-credit-card"></i><span class="app-menu__label">Accountent Details</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="table-data-table.php"><i class="icon fa fa-circle-o"></i> Orphans Members </a></li>
            <li><a class="treeview-item" href="wajane_table.php"><i class="icon fa fa-circle-o"></i> Widows Members</a></li>
             <li><a class="treeview-item" href="user_table.php"><i class="icon fa fa-circle-o"></i> User Registered</a></li>

              <li><a class="treeview-item" href="make_sadaka.php"><i class="icon fa fa-circle-o"></i> Make Charity</a></li>
            <li><a class="treeview-item" href="downlod_charity.php"><i class="icon fa fa-circle-o"></i> Download Member</a></li>


            </ul>
        </li>



         <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-tasks"></i><span class="app-menu__label">Projects Details</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="table-data-table.php"><i class="icon fa fa-circle-o"></i> Orphans Members </a></li>
            <li><a class="treeview-item" href="wajane_table.php"><i class="icon fa fa-circle-o"></i> Widows Members</a></li>
             <li><a class="treeview-item" href="user_table.php"><i class="icon fa fa-circle-o"></i> User Registered</a></li>

              <li><a class="treeview-item" href="make_sadaka.php"><i class="icon fa fa-circle-o"></i> Make Charity</a></li>
            <li><a class="treeview-item" href="downlod_charity.php"><i class="icon fa fa-circle-o"></i> Download Member</a></li>


            </ul>
        </li>




         <!--

        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-file-text"></i><span class="app-menu__label">Pages</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="blank-page.html"><i class="icon fa fa-circle-o"></i> Blank Page</a></li>
            <li><a class="treeview-item" href="page-login.html"><i class="icon fa fa-circle-o"></i> Login Page</a></li>
            <li><a class="treeview-item" href="page-lockscreen.html"><i class="icon fa fa-circle-o"></i> Lockscreen Page</a></li>
            <li><a class="treeview-item" href="page-user.html"><i class="icon fa fa-circle-o"></i> User Page</a></li>
            <li><a class="treeview-item" href="page-invoice.html"><i class="icon fa fa-circle-o"></i> Invoice Page</a></li>
            <li><a class="treeview-item" href="page-calendar.html"><i class="icon fa fa-circle-o"></i> Calendar Page</a></li>
            <li><a class="treeview-item" href="page-mailbox.html"><i class="icon fa fa-circle-o"></i> Mailbox</a></li>
            <li><a class="treeview-item" href="page-error.html"><i class="icon fa fa-circle-o"></i> Error Page</a></li>
          </ul>
        </li>

        -->


        <li><a class="app-menu__item" href="http://localhost/almain/logout.php"><i class="fa fa-sign-out fa-lg"></i><span class="app-menu__label">Logout</span></a>
       </li>


      </ul>
    </aside>