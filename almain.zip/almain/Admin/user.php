<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>


  <script type='text/javascript'>
    function preview_image(event) 
    {
     var reader = new FileReader();
     reader.onload = function()
     {
      var output = document.getElementById('output_image');
      output.src = reader.result;
     }
     reader.readAsDataURL(event.target.files[0]);
    }
 </script>





<?php
  include('../db/db.php');
 
?>


<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
    <?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
     <?php include('navbar.php') ?>


    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i> Staff Registertion Form</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        </ul>
      </div>




      <div class="col-lg-12">

            <div class="panel panel-default">

<?php
$mgs=0;

if (isset($_POST['submit'])) { // if save button on the form is clicked
    
       $name = $_POST['name'];
       $gender = $_POST['gender'];
       $email =  $_POST['email'];
       $password = $_POST['password'];
       $simu = $_POST['simu'];
       $user_type = $_POST['user_type'];
       $image = $_FILES['image']['name'];


     $destination1 = 'staff/' . $image;
     $file1 = $_FILES['image']['tmp_name'];

    if($file1){
  move_uploaded_file($file1, $destination1);           

$sql = mysqli_query($conn,"INSERT INTO user(name,gender,password,email,simu, user_type, image)
     VALUES('$name', '$gender', '$password', '$email', '$simu','$user_type', '$image')");



 if($sql){
                 $mgs=1;
                }
             else{
                  echo"<div class= 'alert alert-success'><center><strong><h5>The user already registered</strong></h5></div>";
                }

            ?>
<?php


    }
  }




?>


</div>

<div class="tile">



  <?php if($mgs){

  ?>

  <div class="alert alert-success">
    <center><strong><h5>UMEFANIKIWA!</strong> KUINGIZA TAARIFA;</h5>

  </div>

<?php   }?>





       <form action="user.php" method="POST" enctype="multipart/form-data">

        <div class="picha">
                 <img class="prof" id="output_image"/ width="90" src="images/<?php echo $image; ?>" name="image"> 
                    <input type="file" accept="image/*" onchange="preview_image(event)" name="image" required="">
              </div>

<br>
<hr>

              <div class="form-row">


              <div class="col-md-6 mb-4">
                  <label>Full Name <b style="color: red">*</b></label>
                  <input type="text" class="form-control" placeholder="Full Name" name="name" required="">

                </div>


                <div class="col-md-6 mb-4">
                  <label>Select Gender <b style="color: red">*</b></label>
                  <select class="form-control" required="" name="gender" required="">
                        <option value="">--Chagua Jinsia--</option> 
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                </select>
                </div>
              

                <div class="col-md-6 mb-4">
                  <label>Email <b style="color: red">*</b></label>
                  <input type="email" class="form-control" placeholder="Email" name="email" required="">

                </div>


            

                <div class="col-md-6 mb-4">
                  <label>Phone Number <b style="color: red">*</b></label>
                  <input type="text" class="form-control" placeholder="Phone Number" name="simu" required="" maxlength="10">

                </div>

                <div class="col-md-6 mb-4">
                  <label>Select User Type <b style="color: red">*</b></label>
                  <select class="form-control" required="" name="user_type" required="">
                        <option value="">--Select User Type--</option> 
                        <option value="Account">Account</option>
                        <option value="Reception">Reception</option>
                        <option value="Miradi">Miradi</option>
                        <option value="Administratior">Admin</option>
                </select>
                </div>


                <div class="col-md-6 mb-4">
                  <label>Password <b style="color: red">*</b></label>
                  <input type="password" class="form-control" placeholder="Password" name="password" required="">

                </div>

          
                
                                 
                 <br>
                <br>
               
                <div class="form-grop">
                    <input type="submit" name="submit" value="Send" class="btn btn-primary">
               </div>

               </form>

</div>
</div>

<br>

</div>

</main>

    <?php include('js.php') ?>



<!--
  Kuvuta Mikoa Katika Data bases
-->


  

    
  </body>
</html>