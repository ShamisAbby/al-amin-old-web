<?php
session_start();
if(!isset($_SESSION["email"])){
  header ("location:http://localhost/almain/index.php");
}
?>



<?php include('header.php') ?>


  <body class="app sidebar-mini">
    <!-- Navbar-->
   

<?php include('topmenu.php') ?>


    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>



    <?php include('navbar.php') ?>


    <?php
include("../db/db.php");
$sql = "SELECT count(id) as total from user";
$data=mysqli_query($conn,$sql);
$result=mysqli_query($conn,"SELECT* from user");
?>


 <?php
include("../db/db.php");
$s = "SELECT count(id) as t from wajane";
$d=mysqli_query($conn,$s);
$r=mysqli_query($conn,"SELECT* from wajane");
?>


<?php
include("../db/db.php");
$ss = "SELECT count(id) as tr from wanafunzi";
$dd=mysqli_query($conn,$ss);
$rr=mysqli_query($conn,"SELECT* from wanafunzi");
?>

<!--
<?php
//include("db/db.php");
//$sss = "SELECT sum(amount) as sr from salary";
//$ddd=mysqli_query($conn,$sss);
//$rrr=mysqli_query($conn,"SELECT* from salary");
?>
-->






    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
          <p>Al-Amin Relief Foundation</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-6 col-lg-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-users fa-3x"></i>
            <div class="info">
              <h4>Staff </h4>
              <p><b>

                <?php

                          while($r=mysqli_fetch_assoc($data))
                            {
                              echo $r['total'];
                            }

                            ?>
                
              </b><b style="color: green">Staff</b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-handshake-o fa-3x"></i>
            <div class="info">
              <h4>Reception</h4>
              <p><b>

                 <?php

                      while($ss=mysqli_fetch_assoc($dd))
                        {
                          echo $ss['tr'];
                        }

                  ?>

              </b><b style="color: red">Member</b></p>
               

              </b></p>
            </div>
          </div>
        </div>


        <div class="col-md-6 col-lg-3">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-credit-card fa-3x"></i>
            <div class="info">
              <h4>Accountent</h4>
              <p><b>

                 <?php

                          while($s=mysqli_fetch_assoc($d))
                            {
                              echo $s['t'];
                            }

                          ?>

              </b><b style="color: blue">People</b></p>
            </div>
          </div>
        </div>


        <div class="col-md-6 col-lg-3">
          <div class="widget-small danger coloured-icon"><i class="icon fa fa-tasks fa-3x"></i>
            <div class="info">
              <h4>Projects</h4>
              <p><b>0</b></p>
            </div>
          </div>
        </div>
      </div>

    </main>


    <?php include('js.php') ?>
    
  </body>
</html>

